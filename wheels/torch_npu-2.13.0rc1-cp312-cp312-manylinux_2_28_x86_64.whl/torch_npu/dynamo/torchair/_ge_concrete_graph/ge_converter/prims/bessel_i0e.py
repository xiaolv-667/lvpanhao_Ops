from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.prims.bessel_i0e.default)
def conveter_prims_bessel_i0e_default(self: Tensor, meta_outputs: TensorSpec = None):
    """NB: prims::bessel_i0e(Tensor self) -> Tensor"""
    raise NotImplementedError("torch.ops.prims.bessel_i0e.default ge_converter is not implemented!")
