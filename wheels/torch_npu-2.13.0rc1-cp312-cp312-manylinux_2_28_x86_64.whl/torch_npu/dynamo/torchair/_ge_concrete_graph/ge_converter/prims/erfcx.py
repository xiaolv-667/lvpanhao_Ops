from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.prims.erfcx.default)
def conveter_prims_erfcx_default(self: Tensor, meta_outputs: TensorSpec = None):
    """NB: prims::erfcx(Tensor self) -> Tensor"""
    raise NotImplementedError("torch.ops.prims.erfcx.default ge_converter is not implemented!")
