from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.prims.erf_inv.default)
def conveter_prims_erf_inv_default(self: Tensor, meta_outputs: TensorSpec = None):
    """NB: prims::erf_inv(Tensor self) -> Tensor"""
    raise NotImplementedError("torch.ops.prims.erf_inv.default ge_converter is not implemented!")
