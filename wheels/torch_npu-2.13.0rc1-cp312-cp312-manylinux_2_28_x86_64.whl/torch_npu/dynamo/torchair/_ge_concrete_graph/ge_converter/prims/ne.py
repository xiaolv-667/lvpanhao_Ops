from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.prims.ne.default)
def conveter_prims_ne_default(self: Tensor, other: Tensor, meta_outputs: TensorSpec = None):
    """NB: prims::ne(Tensor self, Tensor other) -> Tensor"""
    raise NotImplementedError("torch.ops.prims.ne.default ge_converter is not implemented!")
