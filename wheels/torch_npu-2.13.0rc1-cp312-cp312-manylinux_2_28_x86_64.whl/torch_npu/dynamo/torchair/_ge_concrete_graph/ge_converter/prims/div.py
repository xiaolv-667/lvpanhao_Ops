from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.prims.div.default)
def conveter_prims_div_default(self: Tensor, other: Tensor, meta_outputs: TensorSpec = None):
    """NB: prims::div(Tensor self, Tensor other) -> Tensor"""
    raise NotImplementedError("torch.ops.prims.div.default ge_converter is not implemented!")
