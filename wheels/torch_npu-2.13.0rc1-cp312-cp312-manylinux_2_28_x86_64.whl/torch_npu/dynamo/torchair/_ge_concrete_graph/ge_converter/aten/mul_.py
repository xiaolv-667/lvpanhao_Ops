from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.aten.mul_.Tensor)
def conveter_aten_mul__Tensor(self: Tensor, other: Tensor, meta_outputs: TensorSpec = None):
    """NB: aten::mul_.Tensor(Tensor(a!) self, Tensor other) -> Tensor(a!)"""
    raise NotImplementedError("torch.ops.aten.mul_.Tensor ge_converter is not implemented!")


@register_fx_node_ge_converter(torch.ops.aten.mul_.Scalar)
def conveter_aten_mul__Scalar(self: Tensor, other: Union[Number, Tensor], meta_outputs: TensorSpec = None):
    """NB: aten::mul_.Scalar(Tensor(a!) self, Scalar other) -> Tensor(a!)"""
    raise NotImplementedError("torch.ops.aten.mul_.Scalar ge_converter is not implemented!")
