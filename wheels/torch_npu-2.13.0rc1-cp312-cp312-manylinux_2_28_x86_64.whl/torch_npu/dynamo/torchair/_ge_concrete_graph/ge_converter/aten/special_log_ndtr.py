from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.aten.special_log_ndtr.default)
def conveter_aten_special_log_ndtr_default(self: Tensor, meta_outputs: TensorSpec = None):
    """NB: aten::special_log_ndtr(Tensor self) -> Tensor"""
    raise NotImplementedError("torch.ops.aten.special_log_ndtr.default ge_converter is not implemented!")


@register_fx_node_ge_converter(torch.ops.aten.special_log_ndtr.out)
def conveter_aten_special_log_ndtr_out(self: Tensor, *, out: Tensor = None, meta_outputs: TensorSpec = None):
    """NB: aten::special_log_ndtr.out(Tensor self, *, Tensor(a!) out) -> Tensor(a!)"""
    raise NotImplementedError("torch.ops.aten.special_log_ndtr.out ge_converter is not implemented!")
