from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.aten.ge_.Scalar)
def conveter_aten_ge__Scalar(self: Tensor, other: Union[Number, Tensor], meta_outputs: TensorSpec = None):
    """NB: aten::ge_.Scalar(Tensor(a!) self, Scalar other) -> Tensor(a!)"""
    raise NotImplementedError("torch.ops.aten.ge_.Scalar ge_converter is not implemented!")


@register_fx_node_ge_converter(torch.ops.aten.ge_.Tensor)
def conveter_aten_ge__Tensor(self: Tensor, other: Tensor, meta_outputs: TensorSpec = None):
    """NB: aten::ge_.Tensor(Tensor(a!) self, Tensor other) -> Tensor(a!)"""
    raise NotImplementedError("torch.ops.aten.ge_.Tensor ge_converter is not implemented!")
