from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


@register_fx_node_ge_converter(torch.ops.aten.empty_strided.default)
def conveter_aten_empty_strided_default(
    size: Union[List[int], Tensor],
    stride: Union[List[int], Tensor],
    *,
    dtype: Optional[int] = None,
    layout: Optional[int] = None,
    device: Optional[Device] = None,
    pin_memory: Optional[bool] = None,
    meta_outputs: TensorSpec = None,
):
    """NB: aten::empty_strided(SymInt[] size, SymInt[] stride, *, ScalarType? dtype=None, Layout? layout=None, Device? device=None, bool? pin_memory=None) -> Tensor"""
    raise NotImplementedError("torch.ops.aten.empty_strided.default ge_converter is not implemented!")


@register_fx_node_ge_converter(torch.ops.aten.empty_strided.out)
def conveter_aten_empty_strided_out(
    size: Union[List[int], Tensor],
    stride: Union[List[int], Tensor],
    *,
    out: Tensor = None,
    meta_outputs: TensorSpec = None,
):
    """NB: aten::empty_strided.out(SymInt[] size, SymInt[] stride, *, Tensor(a!) out) -> Tensor(a!)"""
    raise NotImplementedError("torch.ops.aten.empty_strided.out ge_converter is not implemented!")
