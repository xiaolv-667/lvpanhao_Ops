from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import
from torchair._ge_concrete_graph.fx2ge_converter import declare_supported
from torchair._ge_concrete_graph.supported_declaration import (
    _TypedTensor,
    F32,
    F16,
    F64,
    I32,
    I16,
    I64,
    I8,
    U8,
    BOOL,
    Support,
)
from torchair._ge_concrete_graph.utils import dtype_promote


@declare_supported(
    [
        Support(F32(2, 2), F32(2, 2), -1.0, 1.0),
        Support(F32(2, 2), F32(2, 2), -2.0, 2.0),
        Support(F16(2, 2), F16(2, 2), -1.0, 1.0),
    ]
)
@register_fx_node_ge_converter(torch.ops.aten.hardtanh_backward.default)
def conveter_aten_hardtanh_backward_default(
    grad_output: Tensor,
    self: Tensor,
    min_val: Union[Number, Tensor],
    max_val: Union[Number, Tensor],
    meta_outputs: TensorSpec = None,
):
    """NB: aten::hardtanh_backward(Tensor grad_output, Tensor self, Scalar min_val, Scalar max_val) -> Tensor"""
    if isinstance(min_val, Tensor) or isinstance(max_val, Tensor):
        raise NotImplementedError(
            "torch.ops.aten.hardtanh_backward.default ge_converter is not implemented "
            "when min_val or max_val is tensor!"
        )
    return ge.HardtanhGrad(self, grad_output, min_val=min_val, max_val=max_val)


@register_fx_node_ge_converter(torch.ops.aten.hardtanh_backward.grad_input)
def conveter_aten_hardtanh_backward_grad_input(
    grad_output: Tensor,
    self: Tensor,
    min_val: Union[Number, Tensor],
    max_val: Union[Number, Tensor],
    *,
    grad_input: Tensor = None,
    meta_outputs: TensorSpec = None,
):
    """NB: aten::hardtanh_backward.grad_input(Tensor grad_output, Tensor self, Scalar min_val, Scalar max_val, *, Tensor(a!) grad_input) -> Tensor(a!)"""
    raise NotImplementedError("torch.ops.aten.hardtanh_backward.grad_input ge_converter is not implemented!")
