from typing import List, Optional

import torch
from torchair._ge_concrete_graph import ge_apis as ge
from torchair._ge_concrete_graph.fx2ge_converter import register_fx_node_ge_converter
from torchair._ge_concrete_graph.ge_converter.converter_utils import GROUP_SIZE_MAX_VALUE
from torchair._utils.check_platform import is_arch35
from torchair.ge._ge_graph import (
    DataType,
    Tensor,
    TensorSpec,
    torch_dtype_value_to_ge_proto_type,
    torch_dtype_value_to_ge_type,
)


def is_transpose_last_two_dims(tensor):
    # GE Tensor本体没有stride/size接口；这里从其 meta（PyTorch meta tensor）取stride信息。
    meta = getattr(tensor, "meta", None)
    if meta is None or not hasattr(meta, "stride") or not hasattr(meta, "size") or not hasattr(meta, "dim"):
        return False

    rank = meta.dim()
    # 仅支持 2D~6D 的张量布局判断。
    if rank < 2 or rank > 6:
        return False

    # 只检查最后两个维度（矩阵维）。
    dim1 = rank - 1
    dim2 = rank - 2

    stride = list(meta.stride())
    size = list(meta.size())

    if stride[dim2] == 1 and stride[dim1] == size[dim2]:
        tmpNxD = size[dim1] * size[dim2]
        # 从倒数第 3 维开始，逐维检查 batch 维 stride 是否连续扩展。
        for batchDim in range(rank - 3, -1, -1):
            if stride[batchDim] != tmpNxD:
                return False
            tmpNxD = tmpNxD * size[batchDim]
        if size[dim1] == 1 and size[dim2] == 1:
            return False
        return True

    return False


def any_dim_is_one(tensor: Tensor) -> bool:
    return any(d == 1 for d in tensor.symsize)


def batch_axis_has_one(tensor: Tensor) -> bool:
    # 仅检查 batch 维：末尾 2 维为矩阵维 (M/K/N 等)；rank < 3 时只有矩阵维、无独立 batch 轴。
    if tensor.rank < 3:
        return False
    for i in range(tensor.rank - 2):
        if tensor.symsize[i] == 1:
            return True
    return False


@register_fx_node_ge_converter(torch.ops.npu.npu_quant_matmul.default)
def conveter_npu_npu_quant_matmul(
    x1: Tensor,
    x2: Tensor,
    scale: Tensor,
    *,
    offset: Optional[Tensor] = None,
    pertoken_scale: Optional[Tensor] = None,
    bias: Optional[Tensor] = None,
    output_dtype: int = None,
    x1_dtype: int = None,
    x2_dtype: int = None,
    pertoken_scale_dtype: int = None,
    scale_dtype: int = None,
    group_sizes: Optional[List[int]] = None,
    y_scale: Optional[Tensor] = None,
    transpose_x1: bool = False,
    transpose_x2: bool = False,
    meta_outputs: TensorSpec = None,
):
    """NB: npu::npu_quant_matmul(Tensor x1, Tensor x2, Tensor scale, *, Tensor? offset=None,
    Tensor? pertoken_scale=None, Tensor? bias=None,
    ScalarType? output_dtype=None) -> Tensor
    """
    import torch_npu

    if (
        not is_arch35()
        and x1.dtype not in [DataType.DT_INT8, DataType.DT_INT32]
        and x2.dtype not in [DataType.DT_INT8, DataType.DT_INT32]
    ):
        raise RuntimeError("In soc versions prior to A5, x1 and x2 only supports int8 or int32.")
    if output_dtype is None:
        output_dtype = 1
    dtype = torch_dtype_value_to_ge_type(output_dtype)
    is_mxfp4_valid = x1_dtype == torch_npu.float4_e2m1fn_x2 and x2_dtype == torch_npu.float4_e2m1fn_x2
    is_a8w4 = x1.dtype == DataType.DT_FLOAT8_E4M3FN and (
        x2_dtype == torch_npu.float4_e2m1fn_x2 or x2.dtype == DataType.DT_FLOAT
    )
    need_reshape = (
        (x1.dtype == DataType.DT_INT32 and x2.dtype == DataType.DT_INT32)
        or (x1_dtype is not None and x2_dtype is not None and x1_dtype == torch_npu.float4_e2m1fn_x2)
        or (is_a8w4 and x2.dtype != DataType.DT_FLOAT and y_scale is not None)
    )
    mxfp4_batch_axis_has_one = False
    if need_reshape and is_mxfp4_valid:
        mxfp4_batch_axis_has_one = batch_axis_has_one(x1) or batch_axis_has_one(x2)
    trans_x2 = x1.symsize[-1] == x2.symsize[-2]
    trans_x1 = False
    if is_mxfp4_valid:
        trans_x1 = is_transpose_last_two_dims(x1)
        trans_x2 = is_transpose_last_two_dims(x2)
    if need_reshape:
        shape_multiples = 2
        x1_ge_dtype = 0
        x2_ge_dtype = 0
        if x1.dtype == DataType.DT_INT32:
            shape_multiples = 8
            x1_ge_dtype = DataType.DT_INT4
            x2_ge_dtype = DataType.DT_INT4
        else:
            if x1_dtype is not None:
                x1_ge_dtype = torch_dtype_value_to_ge_type(x1_dtype)
            if x2_dtype is not None:
                x2_ge_dtype = torch_dtype_value_to_ge_type(x2_dtype)
        if x1.rank < 2:
            raise RuntimeError("Input x1 dimension can't be less than 2, actual x1 dimension is " + str(x1.rank) + ".")
        if x2.rank < 2:
            raise RuntimeError("Input x2 dimension can't be less than 2, actual x2 dimension is " + str(x2.rank) + ".")
        const_x1 = ge.Const([1] * (x1.rank - 1) + [shape_multiples])
        const_x2 = ge.Const([1] * (x2.rank - 1) + [shape_multiples])
        # A8W4 per-group场景把int64的y_scale转成uint64。 同时，A8W4不需要修改x1的数据类型
        if is_a8w4:
            if pertoken_scale is None and y_scale is not None and y_scale.dtype == DataType.DT_INT64:
                y_scale = ge.Bitcast(y_scale, type=DataType.DT_UINT64)
                trans_x2 = x1.symsize[-1] == (x2.symsize[-2] * 2)
        else:
            perm_x1 = list(range(x1.rank))
            perm_x1[-1], perm_x1[-2] = perm_x1[-2], perm_x1[-1]
            if trans_x1:
                x1 = ge.Transpose(x1, perm_x1)
            shape_x1 = ge.Shape(x1)
            shape_x1 = ge.Mul(shape_x1, const_x1)
            x1 = ge.Bitcast(x1, type=x1_ge_dtype)
            x1 = ge.Reshape(x1, shape_x1)
            if trans_x1:
                x1 = ge.Transpose(x1, perm_x1)

        is_simple = True
        if is_mxfp4_valid:
            if scale is not None and any_dim_is_one(scale):
                is_simple = False
            if mxfp4_batch_axis_has_one:
                is_simple = False

        should_keep_dim = is_mxfp4_valid and (is_simple or not trans_x2)
        if should_keep_dim:
            x2 = ge.Bitcast(x2, type=x2_ge_dtype, keep_dim=True)
        else:
            perm_x2 = list(range(x2.rank))
            perm_x2[-1], perm_x2[-2] = perm_x2[-2], perm_x2[-1]
            if trans_x2:
                x2 = ge.Transpose(x2, perm_x2)
            shape_x2 = ge.Shape(x2)
            shape_x2 = ge.Mul(shape_x2, const_x2)
            x2 = ge.Bitcast(x2, type=x2_ge_dtype)
            x2 = ge.Reshape(x2, shape_x2)
            if trans_x2:
                x2 = ge.Transpose(x2, perm_x2)

    group_max = GROUP_SIZE_MAX_VALUE  # 65535是指group_size中的值最大不能超过16位可表示的范围
    group_size = 0
    if group_sizes is not None and isinstance(group_sizes, List):
        if len(group_sizes) != 3:
            raise RuntimeError("group_size must be a list with 3 elements, actual group_sizes is " + str(group_sizes))
        group_m = group_sizes[0]
        group_n = group_sizes[1]
        group_k = group_sizes[2]
        if group_m > group_max or group_n > group_max or group_k > group_max:
            raise RuntimeError("group_size can't larger than 65535, actual group_sizes is " + str(group_sizes))
        if group_m < 0 or group_n < 0 or group_k < 0:
            raise RuntimeError("group_size can't smaller than 0, actual group_sizes is " + str(group_sizes))
        group_size = (group_m << 32) + (group_n << 16) + group_k
        if is_a8w4:
            group_size = group_k
    if x1_dtype is not None:
        if x1_dtype != torch_npu.float4_e2m1fn_x2:
            x1 = ge.Bitcast(x1, type=torch_dtype_value_to_ge_type(x1_dtype))
        x1.desc.dtype = torch_dtype_value_to_ge_proto_type(x1_dtype)
    if x2_dtype is not None:
        if x2_dtype != torch_npu.float4_e2m1fn_x2:
            x2 = ge.Bitcast(x2, type=torch_dtype_value_to_ge_type(x2_dtype))
        x2.desc.dtype = torch_dtype_value_to_ge_proto_type(x2_dtype)
    if pertoken_scale_dtype is not None:
        perm = []
        trans_x1_scale = False
        if is_mxfp4_valid and pertoken_scale_dtype == torch_npu.float8_e8m0fnu:
            trans_x1_scale = trans_x1
            if trans_x1_scale:
                perm = list(range(pertoken_scale.rank))
                perm[-2], perm[-3] = perm[-3], perm[-2]
        if trans_x1_scale:
            pertoken_scale = ge.Transpose(pertoken_scale, perm)
        pertoken_scale = ge.Bitcast(pertoken_scale, type=torch_dtype_value_to_ge_type(pertoken_scale_dtype))
        pertoken_scale.desc.dtype = torch_dtype_value_to_ge_proto_type(pertoken_scale_dtype)
        if trans_x1_scale:
            pertoken_scale = ge.Transpose(pertoken_scale, perm)
    if scale_dtype is not None:
        trans_x2_scale = False
        perm = []
        if is_a8w4 and x2.dtype == DataType.DT_FLOAT:
            trans_x2_scale = x1.symsize[-1] == (x2.symsize[-2] * 8)
            if trans_x2_scale:
                if scale.rank < 2:
                    raise RuntimeError(
                        "Input scale dimension should be 2 or 3, actual scale dimension is " + str(scale.rank) + "."
                    )
                elif scale.rank == 3:
                    perm = [1, 0, 2]
                else:
                    perm = list(range(scale.rank))
                    perm[-1], perm[-2] = perm[-2], perm[-1]

        if is_mxfp4_valid and scale_dtype == torch_npu.float8_e8m0fnu and mxfp4_batch_axis_has_one:
            trans_x2_scale = trans_x2
            if trans_x2_scale:
                perm = list(range(scale.rank))
                perm[-2], perm[-3] = perm[-3], perm[-2]
        if trans_x2_scale:
            scale = ge.Transpose(scale, perm)
        scale = ge.Bitcast(scale, type=torch_dtype_value_to_ge_type(scale_dtype))
        scale.desc.dtype = torch_dtype_value_to_ge_proto_type(scale_dtype)
        if trans_x2_scale:
            scale = ge.Transpose(scale, perm)

    if is_a8w4 and y_scale is None:
        if x2.dtype in [DataType.DT_INT8, DataType.DT_UINT8]:
            if x2.symsize[-2] <= 32:  # u8打包fp4，k=64对应weight[0].symsize[-2]=32
                raise RuntimeError(
                    "Current QMM-MxA8W4 does not support k<=64 in graph mode. Please use eager mode if needed."
                )
            x2 = ge.Bitcast(x2, type=torch_dtype_value_to_ge_type(x2_dtype), keep_dim=True)
        elif x2.dtype == DataType.DT_FLOAT and x2.symsize[-2] <= 8:
            # fp32打包fp4，k=64对应weight[0].symsize[-2]=8
            raise RuntimeError(
                "Current QMM-MxA8W4 does not support k<=64 in graph mode. Please use eager mode if needed."
            )

    if is_arch35():
        out = ge.QuantBatchMatmulV4(
            x1,
            x2,
            bias=bias,
            x1_scale=pertoken_scale,
            x2_scale=scale,
            y_scale=y_scale,
            x1_offset=None,
            x2_offset=offset,
            y_offset=None,
            x2_table=None,
            dtype=dtype,
            transpose_x1=False,
            transpose_x2=False,
            group_size=group_size,
        )
        out.desc.dtype = torch_dtype_value_to_ge_proto_type(output_dtype)
    else:
        out = ge.QuantBatchMatmulV3(
            x1,
            x2,
            scale,
            offset=offset,
            bias=bias,
            pertoken_scale=pertoken_scale,
            dtype=dtype,
            transpose_x1=False,
            transpose_x2=False,
        )
    return out
