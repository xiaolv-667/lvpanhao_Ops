from typing import List

import torch  # pylint: disable=unused-import

from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import

# Explicit imports for pylint static analysis
from torchair._ge_concrete_graph.fx2ge_converter import register_fx_node_ge_converter  # pylint: disable=unused-import
from torchair._ge_concrete_graph import ge_apis as ge  # pylint: disable=unused-import
from torchair._ge_concrete_graph.ge_ir_pb2 import DataType as ProtoDataType  # pylint: disable=unused-import
from torchair.ge._ge_graph import (  # pylint: disable=unused-import
    DataType,
    Tensor,
    TensorSpec,
    torch_dtype_value_to_ge_type,
)


@register_fx_node_ge_converter(torch.ops.npu.npu_grouped_dynamic_mx_quant.default)
def conveter_npu_grouped_dynamic_mx_quant_default(
    x: Tensor,
    group_index: Tensor,
    round_mode: str = "rint",
    dst_type: int = 23,  # torch.float8_e5m2 enum value is 23
    blocksize: int = 32,
    scale_alg: int = 0,
    dst_type_max: float = 0.0,
    meta_outputs: List[TensorSpec] = None,
):
    """
    NB: aten::npu_grouped_dynamic_mx_quant(Tensor x, Tensor group_index, *,
                                   str round_mode="rint", int dst_type=torch.float8_e5m2,
                                   int blocksize=32, int scale_alg=0, float dst_type_max = 0.0) -> (Tensor y, Tensor mxscale)
    """
    ge_dst_type = torch_dtype_value_to_ge_type(dst_type)
    if ge_dst_type not in [
        DataType.DT_FLOAT8_E4M3FN,
        DataType.DT_FLOAT8_E5M2,
        DataType.DT_FLOAT4_E2M1,
        DataType.DT_FLOAT4_E1M2,
    ]:
        raise RuntimeError(
            "Parameter dtype only supports torch.float8_e5m2, torch.float8_e4m3fn, torch_npu.float4_e2m1fn_x2, torch_npu.float4_e1m2fn_x2, got "
            + str(dst_type)
        )
    if x.rank != 2:
        raise RuntimeError(f"Input x must be 2-dimensional, got {x.rank}")
    if group_index.rank != 1:
        raise RuntimeError(f"Input group_index must be 1-dimensional, got {group_index.rank}")
    if round_mode not in ("rint", "round", "floor"):
        raise ValueError("Parameter round_mode must be 'rint'/'round'/'floor', got " + round_mode)
    if blocksize != 32:
        raise ValueError(f"Parameter blocksize must be 32, got {blocksize}")
    if scale_alg not in (0, 1, 2):
        raise ValueError(f"Parameter scale_alg must be 0, 1 or 2, got {scale_alg}")
    y, mxscale = ge.GroupedDynamicMxQuant(
        x,
        group_index,
        round_mode=round_mode,
        dst_type=ge_dst_type,
        blocksize=blocksize,
        scale_alg=scale_alg,
        dst_type_max=dst_type_max,
    )
    mxscale.desc.dtype = ProtoDataType.DT_FLOAT8_E8M0

    if dst_type in (296, 297):
        dim_num = x.rank
        bit_shape = []
        for _ in range(dim_num - 1):
            bit_shape.append(1)
        bit_shape.append(2)
        div_x2 = ge.Cast(ge.Const(bit_shape), dst_type=DataType.DT_INT32)
        y_shape_int4 = ge.Shape(y)
        y_shape_uint8 = ge.Div(y_shape_int4, div_x2)
        y_shape_int4_2bit = ge.ConcatV2(
            [y_shape_uint8, ge.Cast(ge.Const([2]), dst_type=DataType.DT_INT32)], concat_dim=0, N=2
        )
        y = ge.Bitcast(ge.Reshape(y, y_shape_int4_2bit), type=DataType.DT_UINT8)
        return ge.Reshape(y, y_shape_uint8), mxscale
    else:
        return y, mxscale
