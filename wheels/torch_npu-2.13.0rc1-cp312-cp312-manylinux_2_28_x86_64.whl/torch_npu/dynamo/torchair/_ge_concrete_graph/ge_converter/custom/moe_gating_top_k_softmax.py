from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import
from torchair._utils.check_platform import is_arch35
from torchair.core.utils import logger


@declare_supported(
    [
        Support(F32(3, 4), BOOL(3), k=1),
    ]
)
@register_fx_node_ge_converter(torch.ops.npu.npu_moe_gating_top_k_softmax.default)
def conveter_npu_moe_gating_top_k_softmax_default(
    x: Tensor,
    finished: Optional[Tensor] = None,
    k: int = 1,
    meta_outputs: TensorSpec = None,
):
    """NB: func: npu_moe_init_routing(Tensor x, Tensor row_idx, Tensor expert_idx, int active_num)
    -> (Tensor, Tensor, Tensor)
    """
    if is_arch35():
        logger.warning(
            "Interface npu_moe_gating_top_k_softmax will no longer be supported on Ascend950, "
            "you can use the interface npu_moe_gating_top_k_softmax_v2 instead."
        )
    return ge.MoeGatingTopKSoftmax(x, finished, k=k)
