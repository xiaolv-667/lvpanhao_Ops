from typing import Optional
from typing import List
import torch
from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import
from torchair._ge_concrete_graph import ge_apis as ge
from torchair._ge_concrete_graph.fx2ge_converter import declare_supported, register_fx_node_ge_converter
from torchair._ge_concrete_graph.supported_declaration import F16, Support
from torchair.ge._ge_graph import (
    Tensor,
    TensorSpec,
    DataType,
    torch_dtype_value_to_ge_type,
    torch_dtype_value_to_ge_proto_type,
)


@declare_supported(
    [
        Support(F16(1, 2, 3), F16(1, 2, 3), F16(3), output_mask=[True, True]),
        Support(F16(1, 2, 3), F16(1, 2, 3), F16(3), smooth_scale1=F16(3), output_mask=[True, True]),
    ]
)
@register_fx_node_ge_converter(torch.ops.npu.npu_add_rms_norm_dynamic_quant.default)
def convert_npu_add_rms_norm_dynamic_quant_default(
    x1: Tensor,
    x2: Tensor,
    gamma: Tensor,
    smooth_scale1: Optional[Tensor] = None,
    smooth_scale2: Optional[Tensor] = None,
    beta: Optional[Tensor] = None,
    epsilon: float = 1e-6,
    output_mask: Optional[List] = None,
    y_dtype: Optional[int] = None,
    meta_outputs: List[TensorSpec] = None,
):
    """NB: npu::npu_add_rms_norm_dynamic_quant(Tensor x1, Tensor x2, Tensor gamma, *, Tensor? smooth_scale1=None, Tensor? smooth_scale2=None, Tensor? beta=None, float epsilon=1e-6, bool[2]? output_mask=None, int? y_dtype=None) -> (Tensor, Tensor, Tensor, Tensor, Tensor)"""
    dst_type = 1
    if y_dtype is not None:
        dst_type = y_dtype

    mask = []
    if output_mask is not None:
        mask = output_mask

    acl_dst_type = torch_dtype_value_to_ge_type(dst_type)
    y1, y2, x, scale1, scale2 = ge.AddRmsNormDynamicQuant(
        x1,
        x2,
        gamma,
        smooth_scale1=smooth_scale1,
        smooth_scale2=smooth_scale2,
        beta=beta,
        epsilon=epsilon,
        output_mask=mask,
        dst_type=acl_dst_type,
    )

    is_out_y1 = True
    is_out_y2 = False
    if output_mask is None:
        scale1_exists = smooth_scale1 is not None
        scale2_exists = smooth_scale2 is not None
        is_out_y2 = scale1_exists and scale2_exists
    else:
        is_out_y1 = output_mask[0]
        is_out_y2 = output_mask[1]

    y1.desc.dtype = torch_dtype_value_to_ge_proto_type(dst_type)
    y2.desc.dtype = torch_dtype_value_to_ge_proto_type(dst_type)

    if not is_out_y1:
        y1 = ge.Const([], dtype=acl_dst_type)
        scale1 = ge.Const([], dtype=DataType.DT_FLOAT)
    if not is_out_y2:
        y2 = ge.Const([], dtype=acl_dst_type)
        scale2 = ge.Const([], dtype=DataType.DT_FLOAT)

    if acl_dst_type == DataType.DT_INT4:
        dim_num = x1.rank
        bit_shape = []
        for _ in range(dim_num - 1):
            bit_shape.append(1)
        bit_shape.append(8)
        div_x2 = ge.Const(bit_shape, dtype=DataType.DT_INT32)
        if is_out_y1:
            y_shape_int4 = ge.Shape(y1)
            y_shape_int32 = ge.Div(y_shape_int4, div_x2)
            y_shape_int4_4bit = ge.ConcatV2([y_shape_int32, ge.Const([8], dtype=DataType.DT_INT32)], concat_dim=0, N=2)
            y1 = ge.Bitcast(ge.Reshape(y1, y_shape_int4_4bit), type=DataType.DT_INT32)
            y1 = ge.Reshape(y1, y_shape_int32)
        else:
            y1 = ge.Const([], dtype=DataType.DT_INT32)
        if is_out_y2:
            y_shape_int4 = ge.Shape(y2)
            y_shape_int32 = ge.Div(y_shape_int4, div_x2)
            y_shape_int4_4bit = ge.ConcatV2([y_shape_int32, ge.Const([8], dtype=DataType.DT_INT32)], concat_dim=0, N=2)
            y2 = ge.Bitcast(ge.Reshape(y2, y_shape_int4_4bit), type=DataType.DT_INT32)
            y2 = ge.Reshape(y2, y_shape_int32)
        else:
            y2 = ge.Const([], dtype=DataType.DT_INT32)
    return y1, y2, x, scale1, scale2
