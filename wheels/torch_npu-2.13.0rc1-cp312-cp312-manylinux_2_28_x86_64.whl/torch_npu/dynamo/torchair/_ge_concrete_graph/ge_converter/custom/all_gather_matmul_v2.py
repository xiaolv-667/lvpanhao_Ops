from typing import (
    Any,
    Callable,
    ContextManager,
    Iterator,
    List,
    Literal,
    NamedTuple,
    Optional,
    Sequence,
    Tuple,
    TypeVar,
    Union,
    overload,
)

import torch
from torch import Generator, contiguous_format, inf, strided, SymInt
from torch.types import Device, Number, _bool, _complex, _device, _dtype, _float, _int, _layout, _qscheme, _size
from torchair._ge_concrete_graph import ge_apis as ge
from torchair._ge_concrete_graph.fx2ge_converter import declare_supported, register_fx_node_ge_converter
from torchair.ge._ge_graph import (
    Tensor,
    TensorSpec,
    DataType,
    torch_dtype_value_to_ge_proto_type,
    torch_dtype_value_to_ge_type,
    ge_type_to_torch_type,
    _ge_dtype_to_ge_proto_dtype,
)
from torchair._ge_concrete_graph.supported_declaration import (
    _TypedTensor,
    F32,
    F16,
    F64,
    I32,
    I16,
    I64,
    I8,
    U8,
    BOOL,
    Support,
)
from torchair._ge_concrete_graph.ge_converter.converter_utils import *  # pylint: disable=wildcard-import,unused-wildcard-import


X1_X2_SAME_TYPES = {DataType.DT_FLOAT16, DataType.DT_BF16, DataType.DT_HIFLOAT8}
FP8_TYPES = {DataType.DT_HIFLOAT8, DataType.DT_FLOAT8_E4M3FN, DataType.DT_FLOAT8_E5M2}
GROUP_SIZE_MAX_VALUE = 65535
WORLD_SIZE_SUPPORT_LIST = [2, 4, 8, 16, 32, 64]


@declare_supported(
    [
        Support(
            F16(1024, 1024),
            F16(1024, 1024),
            hcom="94430305206192",
            world_size=8,
            bias=None,
            x1_scale=None,
            x2_scale=None,
            quant_scale=None,
            block_size=0,
            gather_index=0,
            gather_output=True,
            comm_turn=0,
            group_sizes=None,
            amax_output=False,
            y_dtype=None,
            x1_dtype=None,
            x2_dtype=None,
            x1_scale_dtype=None,
            x2_scale_dtype=None,
        )
    ]
)
@register_fx_node_ge_converter(torch.ops.npu.npu_all_gather_quant_mm.default)
def convert_npu_all_gather_quant_mm(
    self: Tensor,
    x2: Tensor,
    hcom: str,
    world_size: int,
    bias: Optional[Tensor] = None,
    x1_scale: Optional[Tensor] = None,
    x2_scale: Optional[Tensor] = None,
    quant_scale: Optional[Tensor] = None,
    block_size: int = 0,
    gather_index: int = 0,
    gather_output: bool = True,
    comm_turn: int = 0,
    group_sizes: Optional[List[int]] = None,
    amax_output: bool = False,
    y_dtype: int = None,
    x1_dtype: int = None,
    x2_dtype: int = None,
    x1_scale_dtype: int = None,
    x2_scale_dtype: int = None,
    comm_mode: str = None,
    meta_outputs: TensorSpec = None,
):
    import torch_npu

    transpose_x1 = False
    transpose_x2 = False
    '''
    NB: npu::npu_all_gather_quant_mm(Tensor self, Tensor x2, str hcom, int world_size, *,
    Tensor? bias=None, Tensor? x1_scale=None, Tensor? x2_scale=None,
    Tensor? quant_scale=None, int block_size=0, int gather_index=0, bool gather_output=True, int comm_turn=0,
    int[]? group_sizes=None, bool amax_output=False, int? y_dtype=None,
    int? x1_dtype=None, int? x2_dtype=None, int? x1_scale_dtype=None,
    int? x2_scale_dtype=None, str? comm_mode=None) -> (Tensor, Tensor, Tensor)
    '''
    check_dtype(
        self,
        x2,
        x1_dtype,
        x2_dtype,
        x1_scale_dtype,
        x2_scale_dtype,
        y_dtype=y_dtype,
    )
    if world_size not in WORLD_SIZE_SUPPORT_LIST:
        raise RuntimeError(f"world_size only supports value in {WORLD_SIZE_SUPPORT_LIST}, but got {world_size}.")
    group_max = GROUP_SIZE_MAX_VALUE  # 65535是指group_size中的值最大不能超过16位可表示的范围
    group_size = 0
    if group_sizes is not None and isinstance(group_sizes, List):
        if len(group_sizes) != 3:
            raise RuntimeError("group_size must be a list with 3 elements, actual group_sizes is " + str(group_sizes))
        group_m = group_sizes[0]
        group_n = group_sizes[1]
        group_k = group_sizes[2]
        if group_m > group_max or group_n > group_max or group_k > group_max:
            raise RuntimeError("group_size can't larger than 65535, actual group_sizes is " + str(group_sizes))
        if group_m < 0 or group_n < 0 or group_k < 0:
            raise RuntimeError("group_size can't smaller than 0, actual group_sizes is " + str(group_sizes))
        group_size = (group_m << 32) + (group_n << 16) + group_k
    output_dtype = self.dtype if y_dtype is None else torch_dtype_value_to_ge_type(y_dtype)
    if self.dtype == DataType.DT_FLOAT16 or self.dtype == DataType.DT_BF16:  # pylint: disable=consider-using-in
        if output_dtype != self.dtype:
            raise RuntimeError(
                f"When input is float16 or bfloat16, output should be the same as input dtype."
                f"Expected out type is {ge_type_to_torch_type(self.dtype)}, "
                f"but got {ge_type_to_torch_type(output_dtype)}"
            )
    if y_dtype is None:
        y_dtype = 1
    if self.rank < 2:
        raise RuntimeError("x1 dimension cannot be less than 2, but actual x1 dimension is: " + str(self.rank) + ".")
    if x2.rank < 2:
        raise RuntimeError("x2 dimension cannot be less than 2, but actual x2 dimension is: " + str(x2.rank) + ".")
    if self.dtype in [DataType.DT_UINT8] and x2.dtype in [DataType.DT_UINT8]:
        is_mxfp4 = torch_npu.float4_e2m1fn_x2 in (x1_dtype, x2_dtype)
        trans_x2 = self.symsize[-1] == x2.symsize[-2]
        x1_ge_proto_dtype = torch_dtype_value_to_ge_proto_type(x1_dtype)
        x2_ge_proto_dtype = torch_dtype_value_to_ge_proto_type(x2_dtype)
        if is_mxfp4:
            factor = 2
            self_const = ge.Const([1] * (self.rank - 1) + [factor])
            self_shape = ge.Shape(self)
            self_new_shape = ge.Mul(self_shape, self_const)
            self = ge.Bitcast(self, type=torch_dtype_value_to_ge_type(x1_dtype))
            self.desc.dtype = x1_ge_proto_dtype
            self = ge.Reshape(self, self_new_shape)

            if trans_x2:
                perm = list(range(x2.rank))
                perm[-2], perm[-1] = perm[-1], perm[-2]
            x2_const = ge.Const([1] * (x2.rank - 1) + [factor])
            if trans_x2:
                x2 = ge.Transpose(x2, perm)
            x2_shape = ge.Shape(x2)
            x2_new_shape = ge.Mul(x2_shape, x2_const)
            x2 = ge.Bitcast(x2, type=torch_dtype_value_to_ge_type(x2_dtype))
            x2.desc.dtype = x2_ge_proto_dtype
            x2 = ge.Reshape(x2, x2_new_shape)
            if trans_x2:
                x2 = ge.Transpose(x2, perm)
        else:
            self = ge.Bitcast(self, type=torch_dtype_value_to_ge_type(x1_dtype))
            self.desc.dtype = x1_ge_proto_dtype
            x2 = ge.Bitcast(x2, type=torch_dtype_value_to_ge_type(x2_dtype))
            x2.desc.dtype = x2_ge_proto_dtype
    if x1_scale_dtype is not None:
        x1_scale = ge.Bitcast(x1_scale, type=torch_dtype_value_to_ge_type(x1_scale_dtype))
        x1_scale.desc.dtype = torch_dtype_value_to_ge_proto_type(x1_scale_dtype)
    if x2_scale_dtype is not None:
        x2_scale = ge.Bitcast(x2_scale, type=torch_dtype_value_to_ge_type(x2_scale_dtype))
        x2_scale.desc.dtype = torch_dtype_value_to_ge_proto_type(x2_scale_dtype)
    (out, gather_out, amax_out) = ge.AllGatherMatmulV2(
        self,
        x2,
        bias=bias,
        x1_scale=x1_scale,
        x2_scale=x2_scale,
        quant_scale=quant_scale,
        group=hcom,
        is_trans_a=transpose_x1,
        is_trans_b=transpose_x2,
        gather_index=gather_index,
        comm_turn=comm_turn,
        rank_size=world_size,
        block_size=block_size,
        group_size=group_size,
        is_gather_out=gather_output,
        is_amax_out=amax_output,
        y_dtype=output_dtype,
        comm_mode=comm_mode,
    )
    # 对于非原生的torch数据类型需要做类型标注
    out.desc.dtype = torch_dtype_value_to_ge_proto_type(y_dtype)
    gather_out_dtype = self.dtype
    if x1_dtype is not None:
        gather_out_dtype = torch_dtype_value_to_ge_type(x1_dtype)
    gather_out.desc.dtype = _ge_dtype_to_ge_proto_dtype(gather_out_dtype)
    if gather_output is True:
        if gather_out_dtype in (DataType.DT_FLOAT4_E2M1, DataType.DT_FLOAT4_E1M2):
            bit_shape = [1, 2]
            div_x2 = ge.Cast(ge.Const(bit_shape), dst_type=DataType.DT_INT32)
            y_shape_int4 = ge.Shape(gather_out)
            y_shape_uint8 = ge.Div(y_shape_int4, div_x2)
            y_shape_int4_2bit = ge.ConcatV2(
                [y_shape_uint8, ge.Cast(ge.Const([2]), dst_type=DataType.DT_INT32)], concat_dim=0, N=2
            )
            gather_out = ge.Bitcast(ge.Reshape(gather_out, y_shape_int4_2bit), type=DataType.DT_UINT8)
            gather_out = ge.Reshape(gather_out, y_shape_uint8)
            gather_out.desc.dtype = torch_dtype_value_to_ge_proto_type(DataType.DT_UINT8)
    return (out, gather_out, amax_out)


_GE_DTYPE_TO_NAME = {
    DataType.DT_FLOAT: "float32",
    DataType.DT_FLOAT16: "float16",
    DataType.DT_INT8: "int8",
    DataType.DT_INT16: "int16",
    DataType.DT_UINT16: "uint16",
    DataType.DT_UINT8: "uint8",
    DataType.DT_INT32: "int32",
    DataType.DT_INT64: "int64",
    DataType.DT_UINT32: "uint32",
    DataType.DT_UINT64: "uint64",
    DataType.DT_BOOL: "bool",
    DataType.DT_DOUBLE: "float64",
    DataType.DT_COMPLEX32: "complex32",
    DataType.DT_COMPLEX64: "complex64",
    DataType.DT_COMPLEX128: "complex128",
    DataType.DT_QINT8: "qint8",
    DataType.DT_QINT32: "qint32",
    DataType.DT_QUINT8: "quint8",
    DataType.DT_BF16: "bfloat16",
    DataType.DT_INT4: "int4",
    DataType.DT_HIFLOAT8: "hifloat8",
    DataType.DT_FLOAT8_E5M2: "float8_e5m2",
    DataType.DT_FLOAT8_E4M3FN: "float8_e4m3fn",
    DataType.DT_FLOAT8_E8M0: "float8_e8m0",
    DataType.DT_FLOAT4_E2M1: "float4_e2m1",
    DataType.DT_FLOAT4_E1M2: "float4_e1m2",
}


def check_dtype(
    x1: Tensor,
    x2: Tensor,
    x1_dtype: int = None,
    x2_dtype: int = None,
    x1_scale_dtype: int = None,
    x2_scale_dtype: int = None,
    y_dtype: int = None,
):
    if (x1.dtype != x2.dtype) and x1.dtype in X1_X2_SAME_TYPES:
        raise AssertionError(f"Type of x1:{x1.dtype} and x2:{x2.dtype} must be same.")
    if x1.dtype in FP8_TYPES and y_dtype is None:
        raise AssertionError(f"When type of x1 is {x1.dtype} should input y_dtype.")
    if x1.dtype in [DataType.DT_UINT8] and x2.dtype in [DataType.DT_UINT8]:
        if x1_dtype is None:
            raise AssertionError("In this quant scene: x1_dtype cannot be none.")
        if x2_dtype is None:
            raise AssertionError("In this quant scene: x2_dtype cannot be none.")
        x1_ge_dtype = torch_dtype_value_to_ge_type(x1_dtype)
        x2_ge_dtype = torch_dtype_value_to_ge_type(x2_dtype)
        is_mxfp4 = DataType.DT_FLOAT4_E2M1 in (x1_ge_dtype, x2_ge_dtype)
        if is_mxfp4:
            if x1_scale_dtype is None:
                raise AssertionError("In mxfp4 quant scene: x1_scale_dtype cannot be none.")
            if x2_scale_dtype is None:
                raise AssertionError("In mxfp4 quant scene: x2_scale_dtype cannot be none.")
            x1scale_ge_dtype = torch_dtype_value_to_ge_type(x1_scale_dtype)
            x2scale_ge_dtype = torch_dtype_value_to_ge_type(x2_scale_dtype)
            if x1_ge_dtype != DataType.DT_FLOAT4_E2M1 or x2_ge_dtype != DataType.DT_FLOAT4_E2M1:
                raise AssertionError(
                    f"In mxfp4 quant scene: the data types of x1 and x2 must both be float4_e2m1, "
                    f"but got x1_dtype:{_GE_DTYPE_TO_NAME.get(x1_ge_dtype)} and x2_dtype:{_GE_DTYPE_TO_NAME.get(x2_ge_dtype)}."
                )
            if x1scale_ge_dtype != DataType.DT_FLOAT8_E8M0 or x2scale_ge_dtype != DataType.DT_FLOAT8_E8M0:
                raise AssertionError(
                    f"In mxfp4 quant scene: the data types of x1scale and x2scale must both be float8_e8m0, "
                    f"but got x1_scale_dtype:{_GE_DTYPE_TO_NAME.get(x1scale_ge_dtype)} "
                    f"and x2_scale_dtype:{_GE_DTYPE_TO_NAME.get(x2scale_ge_dtype)}."
                )
