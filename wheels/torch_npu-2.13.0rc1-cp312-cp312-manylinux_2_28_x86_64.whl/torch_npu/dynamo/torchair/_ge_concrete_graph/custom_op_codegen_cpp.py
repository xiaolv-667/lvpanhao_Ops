from torchair._ge_concrete_graph.custom_op_codegen_common import (
    SchemaInfo,
    SchemaArgInfo,
    generate_reg_op,
    _is_scalar_category,
    find_inplace_arg_index,
)


_CPP_HELPERS = r'''namespace {

at::ScalarType MapGeDtypeToTorch(ge::DataType ge_dtype) {
  switch (ge_dtype) {
    case ge::DT_FLOAT: return at::kFloat;
    case ge::DT_FLOAT16: return at::kHalf;
    case ge::DT_BF16: return at::kBFloat16;
    case ge::DT_DOUBLE: return at::kDouble;
    case ge::DT_INT8: return at::kChar;
    case ge::DT_INT16: return at::kShort;
    case ge::DT_INT32: return at::kInt;
    case ge::DT_INT64: return at::kLong;
    case ge::DT_UINT8: return at::kByte;
    case ge::DT_UINT16: return at::kUInt16;
    case ge::DT_UINT32: return at::kUInt32;
    case ge::DT_UINT64: return at::kUInt64;
    case ge::DT_BOOL: return at::kBool;
    case ge::DT_COMPLEX64: return at::kComplexFloat;
    case ge::DT_COMPLEX128: return at::kComplexDouble;
    case ge::DT_QINT8: return at::kQInt8;
    case ge::DT_QUINT8: return at::kQUInt8;
    case ge::DT_QINT32: return at::kQInt32;
    case ge::DT_FLOAT8_E5M2: return at::kFloat8_e5m2;
    case ge::DT_FLOAT8_E4M3FN: return at::kFloat8_e4m3fn;
    case ge::DT_FLOAT8_E8M0: return at::kFloat8_e8m0fnu;
    default:
      TORCH_CHECK(false, "Unsupported GE data type: ", static_cast<int>(ge_dtype));
      return at::kFloat; // unreachable
  }
}

ge::DataType MapTorchDtypeToGe(at::ScalarType torch_dtype) {
  switch (torch_dtype) {
    case at::kFloat: return ge::DT_FLOAT;
    case at::kHalf: return ge::DT_FLOAT16;
    case at::kBFloat16: return ge::DT_BF16;
    case at::kDouble: return ge::DT_DOUBLE;
    case at::kChar: return ge::DT_INT8;
    case at::kShort: return ge::DT_INT16;
    case at::kInt: return ge::DT_INT32;
    case at::kLong: return ge::DT_INT64;
    case at::kByte: return ge::DT_UINT8;
    case at::kUInt16: return ge::DT_UINT16;
    case at::kUInt32: return ge::DT_UINT32;
    case at::kUInt64: return ge::DT_UINT64;
    case at::kBool: return ge::DT_BOOL;
    case at::kComplexFloat: return ge::DT_COMPLEX64;
    case at::kComplexDouble: return ge::DT_COMPLEX128;
    case at::kQInt8: return ge::DT_QINT8;
    case at::kQUInt8: return ge::DT_QUINT8;
    case at::kQInt32: return ge::DT_QINT32;
    case at::kFloat8_e5m2: return ge::DT_FLOAT8_E5M2;
    case at::kFloat8_e4m3fn: return ge::DT_FLOAT8_E4M3FN;
    case at::kFloat8_e8m0fnu: return ge::DT_FLOAT8_E8M0;
    default:
      TORCH_CHECK(false, "Unsupported Torch data type: ", torch_dtype);
      return ge::DT_FLOAT; // unreachable
  }
}

at::Tensor CreateNpuTensor(const gert::Tensor *ge_tensor) {
  auto dtype = MapGeDtypeToTorch(ge_tensor->GetDataType());
  auto data_ptr = const_cast<void *>(ge_tensor->GetAddr());
  std::vector<int64_t> sizes;
  for (size_t i = 0; i < ge_tensor->GetShape().GetStorageShape().GetDimNum(); ++i) {
    sizes.push_back(ge_tensor->GetShape().GetStorageShape().GetDim(i));
  }
  auto options = at::TensorOptions().dtype(dtype).device(at::kPrivateUse1);
  return at_npu::native::from_blob(data_ptr, sizes, options);
}

// ReadScalarInput: read scalar data from gert::Tensor.
// Scalar inputs from GE Const nodes are always on device for custom ops
// (REG_AUTO_MAPPING_OP path), use aclrtMemcpy D2H to safely read.
std::vector<uint8_t> ReadScalarInput(const gert::Tensor* tensor) {
    size_t byte_size = tensor->GetSize();
    std::vector<uint8_t> buf(byte_size);
    auto ret = aclrtMemcpy(buf.data(), byte_size, tensor->GetAddr(), byte_size, ACL_MEMCPY_DEVICE_TO_HOST);
    TORCH_CHECK(ret == ACL_SUCCESS, "aclrtMemcpy D2H failed in ReadScalarInput, ret=", ret);
    return buf;
}

}  // anonymous namespace
'''


def generate_cpp_helpers() -> str:
    return _CPP_HELPERS


def _extract_int(ir_idx, is_optional=False):
    val = f"static_cast<int64_t>(*reinterpret_cast<const int64_t*>(buf_{ir_idx}.data()))"
    if is_optional:
        val = f"c10::optional<int64_t>({val})"
    return [f"    args.emplace_back({val});"]


def _extract_float(ir_idx, is_optional=False):
    val = f"static_cast<double>(*reinterpret_cast<const float*>(buf_{ir_idx}.data()))"
    if is_optional:
        val = f"c10::optional<double>({val})"
    return [f"    args.emplace_back({val});"]


def _extract_bool(ir_idx, is_optional=False):
    val = f"static_cast<bool>(*reinterpret_cast<const uint8_t*>(buf_{ir_idx}.data()))"
    if is_optional:
        val = f"c10::optional<bool>({val})"
    return [f"    args.emplace_back({val});"]


def _extract_str(ir_idx, is_optional=False):
    return [f"    args.emplace_back(std::string(reinterpret_cast<const char*>(buf_{ir_idx}.data()), buf_{ir_idx}.size()));"]


def _extract_str_list(ir_idx, is_optional=False):
    return [
        f"    std::vector<std::string> str_list_{ir_idx};",
        f"    const char* data_{ir_idx} = reinterpret_cast<const char*>(buf_{ir_idx}.data());",
        f"    size_t total_{ir_idx} = buf_{ir_idx}.size();",
        f"    size_t start_{ir_idx} = 0;",
        f"    for (size_t k_{ir_idx} = 0; k_{ir_idx} < total_{ir_idx}; ++k_{ir_idx}) {{",
        f"      if (data_{ir_idx}[k_{ir_idx}] == '\\0') {{",
        f"        str_list_{ir_idx}.emplace_back(data_{ir_idx} + start_{ir_idx}, k_{ir_idx} - start_{ir_idx});",
        f"        start_{ir_idx} = k_{ir_idx} + 1;",
        f"      }}",
        f"    }}",
        f"    if (start_{ir_idx} < total_{ir_idx}) {{",
        f"      str_list_{ir_idx}.emplace_back(data_{ir_idx} + start_{ir_idx}, total_{ir_idx} - start_{ir_idx});",
        f"    }}",
        f"    args.emplace_back(std::move(str_list_{ir_idx}));",
    ]


def _extract_enum(ir_idx, is_optional=False):
    val = f"static_cast<at::ScalarType>(*reinterpret_cast<const int64_t*>(buf_{ir_idx}.data()))"
    if is_optional:
        val = f"c10::optional<at::ScalarType>({val})"
    return [f"    args.emplace_back({val});"]


def _extract_scalar(ir_idx, is_optional=False):
    if is_optional:
        return [
            f"    if (ge_input_{ir_idx}->GetDataType() == ge::DT_INT64) {{",
            f"      args.emplace_back(c10::optional<c10::Scalar>(c10::Scalar(*reinterpret_cast<const int64_t*>(buf_{ir_idx}.data()))));",
            f"    }} else {{",
            f"      args.emplace_back(c10::optional<c10::Scalar>(c10::Scalar(static_cast<double>(*reinterpret_cast<const float*>(buf_{ir_idx}.data())))));",
            f"    }}",
        ]
    return [
        f"    if (ge_input_{ir_idx}->GetDataType() == ge::DT_INT64) {{",
        f"      args.emplace_back(c10::Scalar(*reinterpret_cast<const int64_t*>(buf_{ir_idx}.data())));",
        f"    }} else {{",
        f"      args.emplace_back(c10::Scalar(static_cast<double>(*reinterpret_cast<const float*>(buf_{ir_idx}.data()))));",
        f"    }}",
    ]


def _extract_int_list(ir_idx, is_optional=False):
    return [
        f"    std::vector<int64_t> list_{ir_idx};",
        f"    size_t count_{ir_idx} = buf_{ir_idx}.size() / sizeof(int64_t);",
        f"    const int64_t* data_{ir_idx} = reinterpret_cast<const int64_t*>(buf_{ir_idx}.data());",
        f"    for (size_t i = 0; i < count_{ir_idx}; ++i) list_{ir_idx}.push_back(data_{ir_idx}[i]);",
        f"    args.emplace_back(std::move(list_{ir_idx}));",
    ]


def _extract_float_list(ir_idx, is_optional=False):
    return [
        f"    std::vector<double> list_{ir_idx};",
        f"    size_t count_{ir_idx} = buf_{ir_idx}.size() / sizeof(float);",
        f"    const float* data_{ir_idx} = reinterpret_cast<const float*>(buf_{ir_idx}.data());",
        f"    for (size_t i = 0; i < count_{ir_idx}; ++i) list_{ir_idx}.push_back(static_cast<double>(data_{ir_idx}[i]));",
        f"    args.emplace_back(std::move(list_{ir_idx}));",
    ]


def _extract_bool_list(ir_idx, is_optional=False):
    return [
        f"    std::vector<bool> list_{ir_idx};",
        f"    size_t count_{ir_idx} = buf_{ir_idx}.size() / sizeof(uint8_t);",
        f"    const uint8_t* data_{ir_idx} = reinterpret_cast<const uint8_t*>(buf_{ir_idx}.data());",
        f"    for (size_t i = 0; i < count_{ir_idx}; ++i) list_{ir_idx}.push_back(static_cast<bool>(data_{ir_idx}[i]));",
        f"    args.emplace_back(std::move(list_{ir_idx}));",
    ]


def _extract_scalar_list(ir_idx, is_optional=False):
    return [
        f"    std::vector<c10::Scalar> scalar_list_{ir_idx};",
        f"    if (ge_input_{ir_idx}->GetDataType() == ge::DT_INT64) {{",
        f"      size_t count_{ir_idx} = buf_{ir_idx}.size() / sizeof(int64_t);",
        f"      const int64_t* data_{ir_idx} = reinterpret_cast<const int64_t*>(buf_{ir_idx}.data());",
        f"      for (size_t i = 0; i < count_{ir_idx}; ++i) scalar_list_{ir_idx}.emplace_back(data_{ir_idx}[i]);",
        f"    }} else {{",
        f"      size_t count_{ir_idx} = buf_{ir_idx}.size() / sizeof(float);",
        f"      const float* data_{ir_idx} = reinterpret_cast<const float*>(buf_{ir_idx}.data());",
        f"      for (size_t i = 0; i < count_{ir_idx}; ++i) scalar_list_{ir_idx}.emplace_back(static_cast<double>(data_{ir_idx}[i]));",
        f"    }}",
        f"    args.emplace_back(std::move(scalar_list_{ir_idx}));",
    ]


_SCALAR_EXTRACTORS = {
    "int": _extract_int,
    "float": _extract_float,
    "bool": _extract_bool,
    "str": _extract_str,
    "str_list": _extract_str_list,
    "enum": _extract_enum,
    "Scalar": _extract_scalar,
    "int_list": _extract_int_list,
    "float_list": _extract_float_list,
    "bool_list": _extract_bool_list,
    "scalar_list": _extract_scalar_list,
}


def _generate_input_extraction_and_args_building(schema_info: SchemaInfo) -> str:
    """Generate code to extract inputs from ctx and build c10::IValue args.

    Uses a runtime variable cur_input to track GetInputTensor index,
    so tensor_list (which occupies N input slots at runtime) doesn't break
    the index for subsequent parameters.

    - ir_idx (codegen-time): used for ge_input_N naming and GetDynamicInputTensor
    - cur_input (runtime): used for GetInputTensor, incremented inside tensor_list loop
    """
    lines = [
        "  size_t cur_input = 0;",
        "  std::vector<c10::IValue> args;",
    ]

    if schema_info.is_out:
        lines.append("  // Pre-allocate output tensors for out-return args")
        lines.append("  // Iterate all returns to track flat output index (DYNAMIC_OUTPUT expands to N slots)")
        lines.append("  size_t flat_output_idx = 0;")
        for i, ret in enumerate(schema_info.returns):
            if ret.is_variadic:
                lines.append(f"  {{ // return {i} is DYNAMIC_OUTPUT, skip its expanded slots")
                lines.append(f"    auto ins_info = ctx->GetIrOutputInstanceInfo({i});")
                lines.append(f"    TORCH_CHECK(ins_info != nullptr, \"GetIrOutputInstanceInfo({i}) returned null\");")
                lines.append(f"    flat_output_idx += ins_info->GetInstanceNum();")
                lines.append(f"  }}")
            elif ret.is_out_return:
                lines.append(f"  {{ // return {i} is out-return, pre-allocate, flat index = flat_output_idx")
                lines.append(f"    const gert::Tensor* out_desc_{i} = ctx->GetOutputTensor(flat_output_idx);")
                lines.append(f"    TORCH_CHECK(out_desc_{i} != nullptr, \"GetOutputTensor(\" << flat_output_idx << \") returned null for return {i}\");")
                lines.append(f"    gert::StorageShape out_shape_{i} = out_desc_{i}->GetShape();")
                lines.append(f"    ge::DataType out_dtype_{i} = out_desc_{i}->GetDataType();")
                lines.append(f"    gert::StorageFormat out_format_{i} = out_desc_{i}->GetFormat();")
                lines.append(f"    gert::Tensor* ge_out_{i} = ctx->MallocOutputTensor(flat_output_idx, out_shape_{i}, out_format_{i}, out_dtype_{i});")
                lines.append(f"    TORCH_CHECK(ge_out_{i} != nullptr, \"MallocOutputTensor failed for return {i}\");")
                lines.append(f"    flat_output_idx++;")
                lines.append(f"  }}")
            else:
                lines.append(f"  {{ // return {i} is normal/inplace output, skip pre-allocation")
                lines.append(f"    flat_output_idx++;")
                lines.append(f"  }}")

    ir_idx = 0

    for arg_idx, arg in enumerate(schema_info.arguments):
        if arg.is_out:
            ret_idx = schema_info.out_arg_to_return[arg_idx]
            lines.append(f"  args.emplace_back(CreateNpuTensor(ge_out_{ret_idx})); // out arg '{arg.name}' -> return {ret_idx}")
            continue

        if arg.type_category == "tensor_list":
            lines.append(f"  std::vector<at::Tensor> tensor_list_{ir_idx};")
            lines.append(f"  for (size_t i = 0; ctx->GetDynamicInputTensor({ir_idx}, i) != nullptr; ++i) {{")
            lines.append(f"    tensor_list_{ir_idx}.emplace_back(CreateNpuTensor(ctx->GetDynamicInputTensor({ir_idx}, i)));")
            lines.append(f"    cur_input++;")
            lines.append(f"  }}")
            lines.append(f"  args.emplace_back(c10::List<at::Tensor>(std::move(tensor_list_{ir_idx})));")
        elif arg.type_category == "tensor":
            lines.append(f"  const gert::Tensor* ge_input_{ir_idx} = ctx->GetInputTensor(cur_input);")
            if arg.is_optional:
                lines.append(f"  if (ge_input_{ir_idx} != nullptr) {{")
                lines.append(f"    args.emplace_back(CreateNpuTensor(ge_input_{ir_idx}));")
                lines.append(f"  }} else {{")
                lines.append(f"    args.emplace_back(c10::IValue());")
                lines.append(f"  }}")
            else:
                lines.append(f"  args.emplace_back(CreateNpuTensor(ge_input_{ir_idx}));")
            lines.append(f"  cur_input++;")
        elif arg.type_category in _SCALAR_EXTRACTORS:
            lines.append(f"  const gert::Tensor* ge_input_{ir_idx} = ctx->GetInputTensor(cur_input);")
            lines.append(f"  if (ge_input_{ir_idx} != nullptr) {{")
            lines.append(f"    auto buf_{ir_idx} = ReadScalarInput(ge_input_{ir_idx});")
            lines.extend(_SCALAR_EXTRACTORS[arg.type_category](ir_idx, arg.is_optional))
            lines.append(f"  }} else {{")
            _emit_default_or_none(lines, arg)
            lines.append(f"  }}")
            lines.append(f"  cur_input++;")
        else:
            lines.append(f"  args.emplace_back(c10::IValue()); // unsupported type: {arg.type_category}")
            lines.append(f"  cur_input++;")
        ir_idx += 1

    return "\n".join(lines)


def _emit_default_or_none(lines, arg: SchemaArgInfo):
    """Emit code to push default value or None for optional/has_default scalar args."""
    if arg.has_default and arg.default_value is not None:
        val = arg.default_value
        if arg.type_category in ("int", "enum"):
            lines.append(f"    args.emplace_back(static_cast<int64_t>({int(val)}));")
        elif arg.type_category == "float":
            lines.append(f"    args.emplace_back(static_cast<double>({float(val)}));")
        elif arg.type_category == "bool":
            lines.append(f"    args.emplace_back({'true' if val else 'false'});")
        elif arg.type_category == "str":
            escaped_val = str(val).replace('\\', '\\\\').replace('"', '\\"')
            lines.append(f"    args.emplace_back(std::string(\"{escaped_val}\"));")
        elif arg.type_category == "int_list":
            items = ", ".join(str(int(v)) for v in val)
            lines.append(f"    args.emplace_back(std::vector<int64_t>{{{items}}});")
        elif arg.type_category == "float_list":
            items = ", ".join(f"static_cast<double>({float(v)})" for v in val)
            lines.append(f"    args.emplace_back(std::vector<double>{{{items}}});")
        elif arg.type_category == "bool_list":
            items = ", ".join("true" if v else "false" for v in val)
            lines.append(f"    args.emplace_back(std::vector<bool>{{{items}}});")
        elif arg.type_category == "Scalar":
            if isinstance(val, int):
                lines.append(f"    args.emplace_back(c10::Scalar(static_cast<int64_t>({int(val)})));")
            else:
                lines.append(f"    args.emplace_back(c10::Scalar(static_cast<double>({float(val)})));")
        elif arg.type_category == "str_list":
            items = []
            for v in val:
                escaped = str(v).replace('\\', '\\\\').replace('"', '\\"')
                items.append(f'std::string("{escaped}")')
            lines.append(f"    args.emplace_back(std::vector<std::string>{{{', '.join(items)}}});")
        elif arg.type_category == "scalar_list":
            scalar_items = []
            for v in val:
                if isinstance(v, int):
                    scalar_items.append(f"c10::Scalar(static_cast<int64_t>({int(v)}))")
                else:
                    scalar_items.append(f"c10::Scalar(static_cast<double>({float(v)}))")
            lines.append(f"    args.emplace_back(std::vector<c10::Scalar>{{{', '.join(scalar_items)}}});")
        else:
            lines.append(f"    args.emplace_back(c10::IValue());")
    else:
        lines.append(f"    args.emplace_back(c10::IValue());")


def _generate_stream_setup() -> str:
    return "\n".join([
        "  aclrtStream ge_stream = static_cast<aclrtStream>(ctx->GetStream());",
        "  int32_t device_id = 0;",
        "  aclrtGetDevice(&device_id);",
        "  c10_npu::NPUStream npu_stream = c10_npu::getStreamFromExternal(ge_stream, device_id);",
        "  c10_npu::NPUStreamGuard stream_guard(npu_stream);",
    ])


def _generate_dispatch(schema_info: SchemaInfo) -> str:
    overload = schema_info.overload if schema_info.overload else ""
    lines = [
        f"  static const auto op_handle = torch::Dispatcher::singleton()"
        f".findSchemaOrThrow(\"{schema_info.full_op_name}\", \"{overload}\");",
        "  op_handle.callBoxed(args);",
        f"  const size_t num_outputs = {len(schema_info.returns)};",
    ]
    return "\n".join(lines)


def _emit_normal_writeback(lines, out_i_var, indent):
    """Emit normal writeback: MallocOutputTensor + memcpy (no inplace special case).

    Calls torch_result.contiguous() to handle non-contiguous tensors (e.g. transpose/
    chunk views). On already-contiguous tensors this is a no-op (returns *this).
    Aligned with Python path which also calls t.contiguous() before writeback.
    """
    pad = " " * indent
    lines.append(f"{pad}torch_result = torch_result.contiguous();")
    lines.append(f"{pad}gert::StorageShape storage_shape;")
    lines.append(f"{pad}gert::Shape& origin_shape = storage_shape.MutableOriginShape();")
    lines.append(f"{pad}origin_shape.SetDimNum(torch_result.dim());")
    lines.append(f"{pad}for (int64_t d = 0; d < torch_result.dim(); ++d) origin_shape.SetDim(d, torch_result.size(d));")
    lines.append(f"{pad}gert::Shape& storage_shape_ref = storage_shape.MutableStorageShape();")
    lines.append(f"{pad}storage_shape_ref.SetDimNum(torch_result.dim());")
    lines.append(f"{pad}for (int64_t d = 0; d < torch_result.dim(); ++d) storage_shape_ref.SetDim(d, torch_result.size(d));")
    lines.append(f"{pad}ge::DataType data_type = MapTorchDtypeToGe(torch_result.scalar_type());")
    lines.append(f"{pad}gert::StorageFormat format;")
    lines.append(f"{pad}size_t tensor_bytes = torch_result.numel() * torch_result.element_size();")
    lines.append(f"{pad}gert::Tensor* ge_out = ctx->MallocOutputTensor({out_i_var}, storage_shape, format, data_type);")
    lines.append(f"{pad}TORCH_CHECK(ge_out != nullptr, \"MallocOutputTensor returned null for output \", {out_i_var});")
    lines.append(f"{pad}aclrtMemcpyAsync(const_cast<void*>(ge_out->GetAddr()), tensor_bytes,")
    lines.append(f"{pad}    torch_result.data_ptr(), tensor_bytes, ACL_MEMCPY_DEVICE_TO_DEVICE, ge_stream);")



def _generate_writeback(schema_info: SchemaInfo) -> str:
    lines = []

    lines.append(f"  TORCH_CHECK(args.size() >= num_outputs, \"Expected at least num_outputs results\");")
    lines.append(f"  size_t result_idx = args.size() - num_outputs;")
    lines.append(f"  size_t flat_out_i = 0;")

    # Iterate all returns in schema order.
    # GE output index == schema return index (REG_OP declares all returns in order).
    # - out-return: skip writeback (already pre-allocated), advance flat_out_i
    # - inplace-return: compute GE input index at runtime, memcpy + MakeOutputRefInput, advance flat_out_i
    # - normal: MallocOutputTensor + memcpy, advance flat_out_i
    # - variadic: expand list, advance flat_out_i per element
    for i, ret in enumerate(schema_info.returns):
        if ret.is_out_return:
            lines.append(f"  // return {i}: out-return, skip writeback (pre-allocated)")
            lines.append(f"  flat_out_i++;")
            lines.append(f"  result_idx++;")
            continue

        if ret.is_inplace_return:
            matched_arg_idx = find_inplace_arg_index(schema_info, ret)
            lines.append(f"  {{ // return {i}: inplace-return, memcpy to input + ref")
            lines.append(f"    at::Tensor torch_result = args[result_idx].toTensor();")
            lines.append(f"    torch_result = torch_result.contiguous();")
            # Compute GE input index at runtime: iterate args before matched_arg_idx,
            # counting non-out args (variadic args expand to N slots via GetDynamicInputTensor)
            lines.append(f"    size_t ge_input_idx = 0;")
            for j in range(matched_arg_idx):
                arg_j = schema_info.arguments[j]
                if arg_j.is_out:
                    continue
                if arg_j.is_variadic:
                    lines.append(f"    for (size_t j_{j} = 0; ctx->GetDynamicInputTensor({j}, j_{j}) != nullptr; ++j_{j}) ge_input_idx++;")
                else:
                    lines.append(f"    ge_input_idx++;")
            lines.append(f"    const gert::Tensor* inplace_input = ctx->GetInputTensor(ge_input_idx);")
            lines.append(f"    TORCH_CHECK(inplace_input != nullptr, \"GetInputTensor(\", ge_input_idx, \") returned null for inplace return {i}\");")
            lines.append(f"    size_t tensor_bytes = torch_result.numel() * torch_result.element_size();")
            lines.append(f"    TORCH_CHECK(tensor_bytes == inplace_input->GetSize(), \"inplace return {i}: tensor_bytes (\", tensor_bytes, \") != input size (\", inplace_input->GetSize(), \")\");")
            lines.append(f"    aclrtMemcpyAsync(const_cast<void*>(inplace_input->GetAddr()), inplace_input->GetSize(),")
            lines.append(f"        torch_result.data_ptr(), tensor_bytes, ACL_MEMCPY_DEVICE_TO_DEVICE, ge_stream);")
            lines.append(f"    ctx->MakeOutputRefInput(flat_out_i, ge_input_idx);")
            lines.append(f"  }}")
            lines.append(f"  flat_out_i++;")
            lines.append(f"  result_idx++;")
            continue

        # Normal writeback
        if ret.is_variadic:
            lines.append(f"  {{ // return {i}: normal variadic writeback")
            lines.append(f"    c10::List<at::Tensor> tensor_list = args[result_idx].toTensorList();")
            lines.append(f"    for (size_t j = 0; j < tensor_list.size(); ++j) {{")
            lines.append(f"      at::Tensor torch_result = tensor_list[j];")
            _emit_normal_writeback(lines, "flat_out_i", indent=6)
            lines.append(f"      flat_out_i++;")
            lines.append(f"    }}")
            lines.append(f"  }}")
        else:
            lines.append(f"  {{ // return {i}: normal writeback")
            lines.append(f"    at::Tensor torch_result = args[result_idx].toTensor();")
            _emit_normal_writeback(lines, "flat_out_i", indent=4)
            lines.append(f"    flat_out_i++;")
            lines.append(f"  }}")
        lines.append(f"  result_idx++;")

    return "\n".join(lines)


def generate_cpp_execute_class(schema_info: SchemaInfo, ge_op_name: str) -> str:
    class_name = ge_op_name

    lines = [
        f"class {class_name} : public ge::EagerExecuteOp {{",
        f" public:",
        f"  ge::Status Execute(gert::EagerOpExecutionContext *ctx) override {{",
    ]

    lines.append(_generate_input_extraction_and_args_building(schema_info))
    lines.append(_generate_stream_setup())
    lines.append(_generate_dispatch(schema_info))
    lines.append(_generate_writeback(schema_info))

    lines.append("    return ge::SUCCESS;")
    lines.append("  }")
    lines.append("};")

    return "\n".join(lines) + "\n"


# GE-only includes: needed for REG_OP (both C++ and Python paths).
_GE_INCLUDES = [
    "#include <graph/custom_op.h>",
    "#include <graph/types.h>",
    "#include <graph/operator_reg.h>",
    "#include <register/op_impl_registry.h>",
]

# Execute-only includes: needed for Execute class (C++ path only).
# These require torch_npu and ACL development headers.
_EXECUTE_INCLUDES = [
    "#include <torch/torch.h>",
    "#include <torch_npu/csrc/aten/common/from_blob.h>",
    "#include <torch_npu/csrc/core/npu/NPUStream.h>",
    "#include <torch_npu/csrc/core/npu/NPUGuard.h>",
    "#include <acl/acl.h>",
]


def generate_cpp_source(schemas, ge_op_names, cpp_op_indices=None) -> str:
    """Generate C++ source for batch compilation.

    Args:
        schemas: List of SchemaInfo
        ge_op_names: List of GE op names
        cpp_op_indices: Set of indices for C++ path ops (generate Execute + REG_AUTO_MAPPING_OP).
                        Indices not in this set are Python path ops (only REG_OP).
                        Defaults to empty set (all Python path) if not specified.
    """
    if cpp_op_indices is None:
        cpp_op_indices = set()

    has_cpp_ops = len(cpp_op_indices) > 0

    parts = []

    # GE includes always needed (for REG_OP)
    parts.append("\n".join(_GE_INCLUDES))
    # Execute includes only needed when there are C++ path ops
    if has_cpp_ops:
        parts.append("\n".join(_EXECUTE_INCLUDES))
    parts.append("")
    parts.append("using namespace ge;")
    parts.append("")
    # Helpers (MapGeDtypeToTorch, CreateNpuTensor, ReadScalarInput) only used by Execute
    if has_cpp_ops:
        parts.append(generate_cpp_helpers())

    for i, (schema_info, ge_op_name) in enumerate(zip(schemas, ge_op_names)):
        parts.append(f"namespace ge {{")
        parts.append(generate_reg_op(schema_info, ge_op_name))
        parts.append(f"}}  // namespace ge")
        parts.append("")
        if i in cpp_op_indices:
            # C++ path: generate Execute class + REG_AUTO_MAPPING_OP
            parts.append(generate_cpp_execute_class(schema_info, ge_op_name))
            parts.append(f"REG_AUTO_MAPPING_OP({ge_op_name});")
            parts.append("")

    return "\n".join(parts)
