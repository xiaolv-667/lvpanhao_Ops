import logging
import os
import tempfile
from typing import List

from torchair._ge_concrete_graph.custom_op_codegen_common import (
    SchemaInfo,
    make_ge_op_name,
    _is_scalar_category,
    find_inplace_arg_index,
)

logger = logging.getLogger(__name__)

# Process-level cache for Python path custom op directory.
# Each process gets one unique tmp directory (via mkdtemp) on first prescan
# that has Python-path ops. Subsequent prescans (multi-graph) reuse it and
# write additional .py files. The directory is appended to ASCEND_CUSTOM_OPP_PATH
# so GE's LoadPythonCustomOpsIfNeeded (called per PreRun) scans it each time.
# GE loads .py files via spec_from_file_location with module_name including
# abs(hash(file_path)), so new files are always loaded (no sys.modules cache hit).
# Files are not cleaned up at exit (aligned with C++ path); rely on /tmp cleanup.
# Note: prescan is called serially from the main thread (npu_fx_compiler),
# no lock needed.
_process_py_dir = None


def _ensure_py_dir() -> str:
    """Ensure the process-level tmp directory exists and is in ASCEND_CUSTOM_OPP_PATH.

    Creates the directory on first call (per process) via mkdtemp (atomic,
    unique) and appends it to ASCEND_CUSTOM_OPP_PATH (preserving any existing
    user-set value). Subsequent calls return the cached path.

    Returns the directory path.
    """
    global _process_py_dir
    if _process_py_dir is not None:
        return _process_py_dir

    _process_py_dir = tempfile.mkdtemp(prefix=f"torchair_custom_op_py_pid{os.getpid()}_")

    existing = os.environ.get("ASCEND_CUSTOM_OPP_PATH", "")
    existing_paths = existing.split(os.pathsep) if existing else []
    if _process_py_dir not in existing_paths:
        if existing:
            os.environ["ASCEND_CUSTOM_OPP_PATH"] = existing + os.pathsep + _process_py_dir
        else:
            os.environ["ASCEND_CUSTOM_OPP_PATH"] = _process_py_dir
    logger.info(f"Python custom op directory: {_process_py_dir}, "
                f"ASCEND_CUSTOM_OPP_PATH={os.environ.get('ASCEND_CUSTOM_OPP_PATH')}")

    return _process_py_dir


def _generate_helper_functions() -> str:
    return '''
import torch
import numpy as np
import contextlib
from ge.custom_op import EagerExecuteOp, EagerOpExecutionContext, register_op_impl

# ACL_MEMCPY_DEVICE_TO_HOST enum value (acl_rt.h: ACL_MEMCPY_HOST_TO_HOST=0,
# ACL_MEMCPY_HOST_TO_DEVICE=1, ACL_MEMCPY_DEVICE_TO_HOST=2).
# Python acl module does not expose this constant, so we define it here.
_ACL_MEMCPY_DEVICE_TO_HOST = 2

# GE DataType enum values used by _read_scalar_from_ge to distinguish
# int (DT_INT64=9) from float (DT_FLOAT=0) for Scalar/scalar_list types.
_GE_DT_FLOAT = 0
_GE_DT_INT64 = 9

# GE dtype enum values aligned with C++ path MapGeDtypeToTorch (custom_op_codegen_cpp.py).
# Only dtypes supported by create_npu_tensors (torchair.llm_datadist) are included here.
# Not included (create_npu_tensors does not support these):
#   DT_QUINT8(19), DT_QINT8(18), DT_QINT32(20) — quantized types
#   DT_FLOAT8_E5M2(31), DT_FLOAT8_E4M3FN(32), DT_FLOAT8_E8M0(33) — float8 types
#   DT_HIFLOAT8(30) — hifloat8
_GE_TO_TORCH_DTYPE = {
    0: torch.float32, 1: torch.float16, 27: torch.bfloat16,
    3: torch.int32, 9: torch.int64, 12: torch.bool,
    2: torch.int8, 10: torch.int16, 4: torch.uint8,
    11: torch.float64, 16: torch.complex64, 17: torch.complex128,
    22: torch.uint16, 23: torch.uint32, 24: torch.uint64,
}
_TORCH_TO_GE_DTYPE = {v: k for k, v in _GE_TO_TORCH_DTYPE.items()}

def _ge_to_torch_dtype(ge_dtype):
    if ge_dtype not in _GE_TO_TORCH_DTYPE:
        raise RuntimeError(f"Unsupported GE dtype: {ge_dtype}")
    return _GE_TO_TORCH_DTYPE[ge_dtype]

def _torch_to_ge_dtype(torch_dtype):
    if torch_dtype not in _TORCH_TO_GE_DTYPE:
        raise RuntimeError(f"Unsupported torch dtype: {torch_dtype}")
    return _TORCH_TO_GE_DTYPE[torch_dtype]

def _wrap_ge_tensor_as_torch(tensor):
    from torchair.llm_datadist import create_npu_tensors
    if tensor is None:
        raise RuntimeError("_wrap_ge_tensor_as_torch: tensor is None")
    addr = tensor.addr
    if addr == 0:
        raise RuntimeError("_wrap_ge_tensor_as_torch: tensor.addr is 0 (null)")
    shape = list(tensor.storage_shape.dims)
    dtype = _ge_to_torch_dtype(tensor.data_type)
    tensors = create_npu_tensors(shape, dtype, [addr])
    if tensors is None or len(tensors) == 0:
        raise RuntimeError("_wrap_ge_tensor_as_torch: create_npu_tensors returned empty")
    return tensors[0]

def _copy_torch_into_ge(torch_tensor, ge_tensor):
    """Copy data from a torch tensor into a GE tensor's device memory.

    Difference from delegate (C++ path):
    - delegate: after op execution, uses torch result's shape to construct
      gert::StorageShape and call MallocOutputTensor, so memory size always
      matches result size.
    - Python path: GE Python binding does not expose StorageShape construction
      (pyi: "Python construction is not exposed in this stage"), so
      malloc_output_tensor can only use ge_out_desc.shape from GE InferShape.
      The GE-allocated memory may differ from torch result's actual size.

    This function uses ge_tensor's shape (same as malloc_output_tensor) to
    create the destination wrapper, and validates that torch tensor's numel
    does not exceed GE tensor's numel to prevent memory overflow.
    """
    from torchair.llm_datadist import create_npu_tensors
    if ge_tensor is None:
        raise RuntimeError("_copy_torch_into_ge: ge_tensor is None")
    addr = ge_tensor.addr
    if addr == 0:
        raise RuntimeError("_copy_torch_into_ge: ge_tensor.addr is 0 (null)")
    ge_shape = list(ge_tensor.storage_shape.dims)
    ge_numel = 1
    for dim in ge_shape:
        ge_numel *= dim
    torch_numel = torch_tensor.numel()
    if torch_numel > ge_numel:
        raise RuntimeError(
            f"_copy_torch_into_ge: torch tensor numel ({torch_numel}) exceeds "
            f"ge tensor numel ({ge_numel}), torch_shape={list(torch_tensor.shape)}, "
            f"ge_shape={ge_shape}")
    dtype = _ge_to_torch_dtype(ge_tensor.data_type)
    dest_tensors = create_npu_tensors(ge_shape, dtype, [addr])
    if dest_tensors is None or len(dest_tensors) == 0:
        raise RuntimeError("_copy_torch_into_ge: create_npu_tensors returned empty")
    dest = dest_tensors[0]
    dest.copy_(torch_tensor)

def _read_scalar_from_ge(tensor, type_category):
    import ctypes
    if tensor is None:
        raise RuntimeError("_read_scalar_from_ge: tensor is None")
    addr = tensor.addr
    if addr == 0:
        raise RuntimeError(f"_read_scalar_from_ge: tensor.addr is 0 (null) for type {type_category}")
    size = tensor.size
    if size == 0:
        raise RuntimeError(f"_read_scalar_from_ge: tensor.size is 0 for type {type_category}")
    # Scalar inputs from GE Const nodes are always on device for custom ops.
    # Use aclrtMemcpy D2H to safely read regardless of placement.
    import acl
    host_buf = (ctypes.c_uint8 * size)()
    ret = acl.rt.memcpy(ctypes.addressof(host_buf), size, addr, size, _ACL_MEMCPY_DEVICE_TO_HOST)
    if ret != 0:
        raise RuntimeError(f"_read_scalar_from_ge: aclrtMemcpy device_to_host failed, ret={ret}")
    raw = bytes(host_buf)
    if type_category == "int":
        return int(np.frombuffer(raw, dtype=np.int64)[0])
    elif type_category == "float":
        return float(np.frombuffer(raw, dtype=np.float32)[0])
    elif type_category == "bool":
        return bool(np.frombuffer(raw, dtype=np.uint8)[0])
    elif type_category == "Scalar":
        if tensor.data_type == _GE_DT_INT64:
            return int(np.frombuffer(raw, dtype=np.int64)[0])
        else:
            return float(np.frombuffer(raw, dtype=np.float32)[0])
    elif type_category == "str":
        return raw.decode('utf-8')
    elif type_category == "str_list":
        if not raw:
            return []
        parts = raw.split(b'\\x00')
        if parts and parts[-1] == b'':
            parts.pop()
        return [s.decode('utf-8') for s in parts]
    elif type_category == "int_list":
        return list(np.frombuffer(raw, dtype=np.int64))
    elif type_category == "float_list":
        return list(np.frombuffer(raw, dtype=np.float32))
    elif type_category == "bool_list":
        return list(np.frombuffer(raw, dtype=np.uint8).astype(bool))
    elif type_category == "scalar_list":
        if tensor.data_type == _GE_DT_INT64:
            return [int(v) for v in np.frombuffer(raw, dtype=np.int64)]
        else:
            return [float(v) for v in np.frombuffer(raw, dtype=np.float32)]
    elif type_category == "enum":
        return int(np.frombuffer(raw, dtype=np.int64)[0])
    raise RuntimeError(f"Unsupported scalar type: {type_category}")

def _normalize_outputs(result):
    if result is None:
        return []
    if isinstance(result, torch.Tensor):
        return [result]
    if isinstance(result, (list, tuple)):
        return list(result)
    return [result]

@contextlib.contextmanager
def _ge_stream_context(ctx):
    import torch_npu
    from torch_npu.npu.streams import ExternalStream
    stream_ptr = ctx.get_stream()
    if stream_ptr:
        ext_stream = ExternalStream(stream_ptr, device=torch.npu.current_device())
        with torch.npu.stream(ext_stream):
            yield
    else:
        yield
'''


def _generate_buildstack(schema_info: SchemaInfo) -> str:
    """Generate code to extract inputs from ctx and build args list.

    Uses dual indexing aligned with C++ path:
    - ir_idx (codegen-time): for get_optional_input_tensor / get_dynamic_input_tensor
    - input_idx (runtime): for get_input_tensor, incremented inside tensor_list loop
    """
    if schema_info.is_out:
        seen_variadic = False
        for ret in schema_info.returns:
            if ret.is_variadic:
                seen_variadic = True
            elif seen_variadic:
                raise RuntimeError(
                    f"Schema '{schema_info.full_op_name}' has Tensor[] return before Tensor return "
                    f"with is_out=True. Python path does not support this (GE Python binding "
                    f"lacks get_ir_output_instance_info to compute flat output index at runtime). "
                    f"C++ path supports this via GetIrOutputInstanceInfo. "
                    f"Please use C++ path (define op via TORCH_LIBRARY in C++)."
                )

    lines = [
        "        args = []",
        "        input_idx = 0",
        "        ir_idx = 0",
    ]

    if schema_info.is_out:
        lines.append("        # Pre-allocate output tensors for out args")
        lines.append("        # Python path uses IR index as flat output index directly.")
        lines.append("        # This works only when all non-variadic returns appear before variadic returns")
        lines.append("        # (enforced by _generate_buildstack). C++ path supports arbitrary order via")
        lines.append("        # GetIrOutputInstanceInfo (not yet available in Python binding).")
        for ret_idx in schema_info.out_return_indices:
            lines.append(f"        _out_desc_{ret_idx} = ctx.get_output_tensor({ret_idx})")
            lines.append(f"        _ge_out_{ret_idx} = ctx.malloc_output_tensor({ret_idx}, _out_desc_{ret_idx}.shape, _out_desc_{ret_idx}.format, _out_desc_{ret_idx}.data_type)")
            lines.append(f"        if _ge_out_{ret_idx} is None:")
            lines.append(f'            raise RuntimeError("malloc_output_tensor({ret_idx}) returned None for out arg")')

    for arg_idx, arg in enumerate(schema_info.arguments):
        if arg.is_out:
            ret_idx = schema_info.out_arg_to_return[arg_idx]
            lines.append(f"        # out arg '{arg.name}' -> return {ret_idx}")
            lines.append(f"        args.append(_wrap_ge_tensor_as_torch(_ge_out_{ret_idx}))")
            continue
 
        if arg.type_category == "tensor_list":
            lines.append(f"        tensor_list = []")
            lines.append(f"        j = 0")
            lines.append(f"        while True:")
            lines.append(f"            try:")
            lines.append(f"                ge_t = ctx.get_dynamic_input_tensor(ir_idx, j)")
            lines.append(f"            except RuntimeError:")
            lines.append(f"                break")
            lines.append(f"            if ge_t is None:")
            lines.append(f"                break")
            lines.append(f"            tensor_list.append(_wrap_ge_tensor_as_torch(ge_t))")
            lines.append(f"            input_idx += 1")
            lines.append(f"            j += 1")
            lines.append(f"        args.append(tensor_list)")
        elif arg.type_category == "tensor":
            if arg.is_optional:
                lines.append(f"        ge_t = ctx.get_optional_input_tensor(ir_idx)")
                lines.append(f"        if ge_t is None:")
                lines.append(f"            args.append(None)  # optional tensor '{arg.name}'")
                lines.append(f"        else:")
                lines.append(f"            args.append(_wrap_ge_tensor_as_torch(ge_t))")
            else:
                lines.append(f"        ge_t = ctx.get_input_tensor(input_idx)")
                lines.append(f"        if ge_t is None:")
                lines.append(f'            raise RuntimeError(f"get_input_tensor({{input_idx}}) returned None for tensor {arg.name!r}")')
                lines.append(f"        args.append(_wrap_ge_tensor_as_torch(ge_t))")
            lines.append(f"        input_idx += 1")
        elif _is_scalar_category(arg.type_category):
            lines.append(f"        ge_t = ctx.get_input_tensor(input_idx)")
            lines.append(f"        if ge_t is None:")
            if arg.has_default and arg.default_value is not None:
                lines.append(f"            args.append({arg.default_value!r})")
            else:
                lines.append(f"            args.append(None)")
            lines.append(f"        else:")
            lines.append(f"            args.append(_read_scalar_from_ge(ge_t, {arg.type_category!r}))")
            lines.append(f"        input_idx += 1")
        else:
            lines.append(f"        args.append(None)  # unsupported type: {arg.type_category}")
            lines.append(f"        input_idx += 1")

        lines.append(f"        ir_idx += 1")
        lines.append("")

    return "\n".join(lines)


def _generate_call_and_writeback(schema_info: SchemaInfo) -> str:
    overload = schema_info.overload if schema_info.overload else "default"

    lines = []
    lines.append(f"        result = torch.ops.{schema_info.namespace_name}.{schema_info.op_name}.{overload}(*args)")
    lines.append("")
    lines.append("        outs = _normalize_outputs(result)")
    lines.append("        _out_idx = 0")
    lines.append("        _flat_out_i = 0")

    # Iterate all returns in schema order.
    # GE output index == schema return index (REG_OP declares all returns in order).
    # - out-return: skip writeback (pre-allocated), advance _flat_out_i
    # - inplace-return: memcpy to input + make_output_ref_input, advance _flat_out_i
    # - normal: malloc + memcpy, advance _flat_out_i
    # - variadic: expand list, advance _flat_out_i per element
    for i, ret in enumerate(schema_info.returns):
        if ret.is_out_return:
            lines.append(f"        # return {i}: out-return, skip writeback (pre-allocated)")
            lines.append(f"        _flat_out_i += 1")
            lines.append(f"        _out_idx += 1")
            continue

        if ret.is_inplace_return:
            matched_arg_idx = find_inplace_arg_index(schema_info, ret)
            lines.append(f"        # return {i}: inplace-return, memcpy to input + ref")
            lines.append(f"        t = outs[_out_idx]")
            lines.append(f"        if not isinstance(t, torch.Tensor):")
            lines.append(f"            t = torch.as_tensor(t)")
            lines.append(f"        t = t.contiguous()")
            # Compute GE input index at runtime
            lines.append(f"        _ge_input_idx = 0")
            for j in range(matched_arg_idx):
                arg_j = schema_info.arguments[j]
                if arg_j.is_out:
                    continue
                if arg_j.is_variadic:
                    lines.append(f"        _j = 0")
                    lines.append(f"        while True:")
                    lines.append(f"            try:")
                    lines.append(f"                _ge_t = ctx.get_dynamic_input_tensor({j}, _j)")
                    lines.append(f"            except RuntimeError:")
                    lines.append(f"                break")
                    lines.append(f"            if _ge_t is None:")
                    lines.append(f"                break")
                    lines.append(f"            _ge_input_idx += 1")
                    lines.append(f"            _j += 1")
                else:
                    lines.append(f"        _ge_input_idx += 1")
            lines.append(f"        inplace_input = ctx.get_input_tensor(_ge_input_idx)")
            lines.append(f"        if inplace_input is None:")
            lines.append(f'            raise RuntimeError(f"get_input_tensor({{_ge_input_idx}}) returned None for inplace return")')
            lines.append(f"        _copy_torch_into_ge(t, inplace_input)")
            lines.append(f"        ctx.make_output_ref_input(_flat_out_i, _ge_input_idx)")
            lines.append(f"        _flat_out_i += 1")
            lines.append(f"        _out_idx += 1")
            continue

        # Normal writeback
        if ret.is_variadic:
            lines.append(f"        # return {i}: normal variadic writeback")
            lines.append(f"        if isinstance(outs[_out_idx], (list, tuple)):")
            lines.append(f"            for t in outs[_out_idx]:")
            lines.append(f"                if not isinstance(t, torch.Tensor):")
            lines.append(f"                    t = torch.as_tensor(t)")
            lines.append(f"                t = t.contiguous()")
            lines.append(f"                ge_out_desc = ctx.get_output_tensor(_flat_out_i)")
            lines.append(f"                ge_out = ctx.malloc_output_tensor(_flat_out_i, ge_out_desc.shape, ge_out_desc.format, _torch_to_ge_dtype(t.dtype))")
            lines.append(f"                if ge_out is None:")
            lines.append(f"                    raise RuntimeError(f'malloc_output_tensor({{_flat_out_i}}) returned None')")
            lines.append(f"                _copy_torch_into_ge(t, ge_out)")
            lines.append(f"                _flat_out_i += 1")
        else:
            lines.append(f"        # return {i}: normal writeback")
            lines.append(f"        t = outs[_out_idx]")
            lines.append(f"        if not isinstance(t, torch.Tensor):")
            lines.append(f"            t = torch.as_tensor(t)")
            lines.append(f"        t = t.contiguous()")
            lines.append(f"        ge_out_desc = ctx.get_output_tensor(_flat_out_i)")
            lines.append(f"        ge_out = ctx.malloc_output_tensor(_flat_out_i, ge_out_desc.shape, ge_out_desc.format, _torch_to_ge_dtype(t.dtype))")
            lines.append(f"        if ge_out is None:")
            lines.append(f"            raise RuntimeError(f'malloc_output_tensor({{_flat_out_i}}) returned None')")
            lines.append(f"        _copy_torch_into_ge(t, ge_out)")
            lines.append(f"        _flat_out_i += 1")
        lines.append(f"        _out_idx += 1")

    lines.append("")
    lines.append("        return True")
    return "\n".join(lines)


def _generate_class_name(ge_op_name: str) -> str:
    return "".join(word.capitalize() for word in ge_op_name.split("_") if word)


def _indent(text: str, spaces: int = 4) -> str:
    pad = " " * spaces
    return "\n".join(pad + line if line.strip() else line for line in text.split("\n"))


def generate_python_op_file_source(schemas: List[SchemaInfo], targets: List) -> str:
    parts = [
        "# Auto-generated by torchair prescan_and_compile_custom_ops",
        "# Do not edit manually.",
        _generate_helper_functions(),
        "",
    ]

    for schema_info, target in zip(schemas, targets):
        ge_op_name = make_ge_op_name(schema_info)
        class_name = _generate_class_name(ge_op_name)

        parts.append(f'@register_op_impl(op_type="{ge_op_name}")')
        parts.append(f"class {class_name}(EagerExecuteOp):")
        parts.append(f"    def execute(self, ctx: EagerOpExecutionContext):")
        parts.append("        with _ge_stream_context(ctx):")
        parts.append(_indent(_generate_buildstack(schema_info)))
        parts.append(_indent(_generate_call_and_writeback(schema_info)))
        parts.append("")

    return "\n".join(parts)


def generate_and_write_python_op_file(schemas: List[SchemaInfo], targets: List, name_suffix: str) -> str:
    py_dir = _ensure_py_dir()

    file_name = f"op_py_{name_suffix}.py"
    file_path = os.path.join(py_dir, file_name)
    source = generate_python_op_file_source(schemas, targets)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(source)
    logger.info(f"Generated Python custom op file: {file_path}")

    return py_dir
