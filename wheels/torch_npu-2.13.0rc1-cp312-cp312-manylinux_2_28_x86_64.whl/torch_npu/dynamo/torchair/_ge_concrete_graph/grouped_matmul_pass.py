from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import torch

from torchair.core.utils import logger
from torchair._ge_concrete_graph.ge_ir_pb2 import DataType, OpDef
from torchair.ge._ge_graph import GeGraph, Tensor


_TRANSPARENT_VIEW_INPUT_OPS = {"Bitcast", "Cast", "Reshape", "Transpose", "TransposeD"}
_FP8_DTYPES = {DataType.DT_HIFLOAT8, DataType.DT_FLOAT8_E5M2, DataType.DT_FLOAT8_E4M3FN}
_FP4_DTYPES = {DataType.DT_FLOAT4_E2M1, DataType.DT_FLOAT4_E1M2}


@dataclass
class _ViewInfo:
    source: Tensor
    result: Tensor
    meta: torch.Tensor


def _tensor_node_name(tensor_name: str) -> str:
    return tensor_name.rsplit(":", 1)[0]


def _tensor_output_index(tensor_name: str) -> int:
    _, separator, output_index = tensor_name.rpartition(":")
    return int(output_index) if separator and output_index.isdigit() else 0


def _build_view_info_map(graph: GeGraph) -> Dict[str, _ViewInfo]:
    result = {}
    for key, view_result in getattr(graph, "view_operator_map", {}).items():
        if not isinstance(key, tuple) or len(key) != 2 or not isinstance(view_result, Tensor):
            continue
        source, meta = key
        if not isinstance(source, Tensor) or not isinstance(meta, torch.Tensor):
            continue
        result[view_result.tensor] = _ViewInfo(source=source, result=view_result, meta=meta)
    return result


def _is_last_two_dims_transpose(meta: torch.Tensor) -> bool:
    if meta.dim() < 2:
        return False
    size = list(meta.size())
    stride = list(meta.stride())
    if stride[-2] != 1 or stride[-1] != size[-2]:
        return False

    contiguous_size = size[-1] * size[-2]
    for batch_dim in range(meta.dim() - 3, -1, -1):
        if stride[batch_dim] != contiguous_size:
            return False
        contiguous_size *= size[batch_dim]
    return size[-1] != 1 or size[-2] != 1


def _is_unit_axis_transpose(meta: torch.Tensor) -> bool:
    size = list(meta.size())
    return _is_last_two_dims_transpose(meta) and (size[-1] == 1 or size[-2] == 1)


def _is_packed_scale_transpose(meta: torch.Tensor) -> bool:
    if meta.dim() < 3:
        return False
    size = list(meta.size())
    stride = list(meta.stride())
    if stride[-1] != 1 or stride[-3] != size[-1] or stride[-2] != size[-3] * size[-1]:
        return False

    contiguous_size = size[-3] * size[-2] * size[-1]
    for batch_dim in range(meta.dim() - 4, -1, -1):
        if stride[batch_dim] != contiguous_size:
            return False
        contiguous_size *= size[batch_dim]
    return True


def _is_per_token_scale_transpose(meta: torch.Tensor) -> bool:
    if meta.dim() == 2:
        return _is_last_two_dims_transpose(meta)
    if meta.dim() == 3:
        return _is_packed_scale_transpose(meta)
    return False


def _input_indices(op: OpDef, prefix: str) -> List[int]:
    return [index for index, desc in enumerate(op.input_desc) if desc.name.startswith(prefix)]


def _source_desc(name_to_op: Dict[str, OpDef], tensor_name: str):
    source_op = name_to_op.get(_tensor_node_name(tensor_name))
    output_index = _tensor_output_index(tensor_name)
    if source_op is None or output_index >= len(source_op.output_desc):
        return None
    return source_op.output_desc[output_index]


def _replace_input(name_to_op: Dict[str, OpDef], consumer: OpDef, input_index: int, tensor_name: str):
    consumer.input[input_index] = tensor_name
    source_desc = _source_desc(name_to_op, tensor_name)
    if source_desc is None or input_index >= len(consumer.input_desc):
        return
    input_name = consumer.input_desc[input_index].name
    consumer.input_desc[input_index].CopyFrom(source_desc)
    consumer.input_desc[input_index].name = input_name


def _find_view_path(
    gmm: OpDef,
    input_index: int,
    name_to_op: Dict[str, OpDef],
    view_infos: Dict[str, _ViewInfo],
) -> Tuple[Optional[_ViewInfo], List[Tuple[OpDef, int]]]:
    if input_index >= len(gmm.input) or not gmm.input[input_index]:
        return None, []

    path = [(gmm, input_index)]
    current_tensor = gmm.input[input_index]
    for _ in range(12):
        if current_tensor in view_infos:
            return view_infos[current_tensor], path
        current_op = name_to_op.get(_tensor_node_name(current_tensor))
        if current_op is None or current_op.type not in _TRANSPARENT_VIEW_INPUT_OPS or not current_op.input:
            return None, []
        path.append((current_op, 0))
        current_tensor = current_op.input[0]
    return None, []


def _bypass_view(name_to_op: Dict[str, OpDef], view_info: _ViewInfo, path: List[Tuple[OpDef, int]]):
    consumer, input_index = path[-1]
    _replace_input(name_to_op, consumer, input_index, view_info.source.tensor)


def _normalize_mxfp4_weight_path(
    name_to_op: Dict[str, OpDef], view_info: _ViewInfo, path: List[Tuple[OpDef, int]]
) -> bool:
    path_types = [consumer.type for consumer, _ in path]
    expected_types = ["GroupedMatmul", "Transpose", "Reshape", "Bitcast", "Transpose"]
    if path_types != expected_types:
        _bypass_view(name_to_op, view_info, path)
        return True

    gmm, gmm_input_index = path[0]
    reshape = path[2][0]
    bitcast = path[3][0]
    inner_transpose = path[4][0]
    _replace_input(name_to_op, bitcast, 0, view_info.source.tensor)
    _replace_input(name_to_op, gmm, gmm_input_index, f"{reshape.name}:0")

    for op in name_to_op.values():
        if op.type == "Shape" and op.input and op.input[0] == f"{inner_transpose.name}:0":
            _replace_input(name_to_op, op, 0, view_info.source.tensor)
    return True


def _all_view_paths(
    gmm: OpDef,
    input_indices: List[int],
    name_to_op: Dict[str, OpDef],
    view_infos: Dict[str, _ViewInfo],
):
    paths = []
    for input_index in input_indices:
        view_info, path = _find_view_path(gmm, input_index, name_to_op, view_infos)
        if view_info is None:
            return []
        paths.append((view_info, path))
    return paths


def _is_dynamic_transpose(view_info: _ViewInfo) -> bool:
    return any(isinstance(dim, torch.SymInt) for dim in view_info.meta.size()) and _is_last_two_dims_transpose(
        view_info.meta
    )


def _normalize_split_k_x(gmm: OpDef, name_to_op: Dict[str, OpDef], view_infos: Dict[str, _ViewInfo]) -> bool:
    x_indices = _input_indices(gmm, "x")
    if gmm.attr["group_type"].i != 2 or len(x_indices) != 1:
        return False

    x_view, x_path = _find_view_path(gmm, x_indices[0], name_to_op, view_infos)
    if x_view is None or not _is_unit_axis_transpose(x_view.meta):
        return False
    _bypass_view(name_to_op, x_view, x_path)

    per_token_indices = _input_indices(gmm, "per_token_scale")
    if per_token_indices:
        scale_view, scale_path = _find_view_path(gmm, per_token_indices[0], name_to_op, view_infos)
        if scale_view is not None and _is_per_token_scale_transpose(scale_view.meta):
            _bypass_view(name_to_op, scale_view, scale_path)
    gmm.attr["transpose_x"].b = True
    return True


def _normalize_weight_and_scale(
    gmm: OpDef,
    name_to_op: Dict[str, OpDef],
    view_infos: Dict[str, _ViewInfo],
    is_mxfp4: bool,
) -> bool:
    if gmm.attr["group_type"].i not in (-1, 0):
        return False
    weight_paths = _all_view_paths(gmm, _input_indices(gmm, "weight"), name_to_op, view_infos)
    scale_paths = _all_view_paths(gmm, _input_indices(gmm, "scale"), name_to_op, view_infos)
    if not weight_paths or not scale_paths:
        return False

    unit_axis_weight = all(
        _is_unit_axis_transpose(view_info.meta) and view_info.meta.size()[-1] == 1 for view_info, _ in weight_paths
    )
    dynamic_weight_scale = (
        gmm.attr["group_list_type"].i == 1
        and all(_is_dynamic_transpose(view_info) for view_info, _ in weight_paths)
        and all(
            _is_packed_scale_transpose(view_info.meta)
            if view_info.meta.dim() >= 4
            else _is_last_two_dims_transpose(view_info.meta)
            for view_info, _ in scale_paths
        )
    )
    if is_mxfp4:
        if not unit_axis_weight and not dynamic_weight_scale:
            return False
    elif not dynamic_weight_scale:
        return False

    for view_info, path in weight_paths:
        if is_mxfp4:
            _normalize_mxfp4_weight_path(name_to_op, view_info, path)
        else:
            _bypass_view(name_to_op, view_info, path)
    for view_info, path in scale_paths:
        _bypass_view(name_to_op, view_info, path)
    gmm.attr["transpose_weight"].b = True
    return True


def normalize_grouped_matmul_view(graph: GeGraph):
    view_infos = _build_view_info_map(graph)
    if not view_infos:
        return

    name_to_op = {op.name: op for op in graph.op}
    for gmm in [op for op in graph.op if op.type == "GroupedMatmul"]:
        x_indices = _input_indices(gmm, "x")
        weight_indices = _input_indices(gmm, "weight")
        if not x_indices or not weight_indices:
            continue
        x_dtype = gmm.input_desc[x_indices[0]].dtype
        weight_dtype = gmm.input_desc[weight_indices[0]].dtype
        is_fp8 = x_dtype in _FP8_DTYPES and weight_dtype in _FP8_DTYPES
        is_mxfp4 = x_dtype in _FP4_DTYPES and weight_dtype in _FP4_DTYPES
        if not is_fp8 and not is_mxfp4:
            continue

        if is_fp8 and _normalize_split_k_x(gmm, name_to_op, view_infos):
            logger.debug("normalize split-k unit-axis transpose for GroupedMatmul %s.", gmm.name)
            continue
        if _normalize_weight_and_scale(gmm, name_to_op, view_infos, is_mxfp4):
            logger.debug("normalize weight and scale transpose for GroupedMatmul %s.", gmm.name)
