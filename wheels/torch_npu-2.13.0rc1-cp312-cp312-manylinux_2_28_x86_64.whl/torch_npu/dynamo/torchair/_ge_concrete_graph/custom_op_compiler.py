import os
import subprocess
import ctypes
import tempfile
from pathlib import Path


# Process-level cache for C++ path custom op directory.
# Each process gets one unique tmp directory (via mkdtemp) on first prescan
# that has C++-path ops. Subsequent prescans (multi-graph) reuse it and write
# additional .cpp/.so files. Files are not cleaned up at exit; rely on /tmp cleanup.
# Note: prescan is called serially from the main thread (npu_fx_compiler),
# no lock needed.
_process_cpp_dir = None


def _ensure_cpp_dir() -> str:
    """Ensure the process-level tmp directory exists.

    Creates the directory on first call (per process) via mkdtemp (atomic,
    unique). Subsequent calls return the cached path.

    Returns the directory path.
    """
    global _process_cpp_dir
    if _process_cpp_dir is not None:
        return _process_cpp_dir

    _process_cpp_dir = tempfile.mkdtemp(prefix=f"torchair_custom_op_cpp_pid{os.getpid()}_")
    return _process_cpp_dir


def discover_torch_dir() -> str:
    import torch

    return os.path.dirname(torch.__file__)


def discover_torch_npu_dir() -> str:
    try:
        import torch_npu

        return os.path.dirname(torch_npu.__file__)
    except ImportError:
        return None


def discover_cann_dir() -> str:
    return os.environ.get("ASCEND_HOME_PATH", "")


def build_gcc_command(
    torch_dir: str, torch_npu_dir: str, cann_dir: str, cpp_path: str, so_path: str, has_cpp_ops: bool = True
) -> list:
    includes = [
        f"-I{torch_dir}/include",
        f"-I{torch_dir}/include/torch/csrc/api/include",
        f"-I{cann_dir}/include",
        f"-I{cann_dir}/include/graph",
        f"-I{cann_dir}/include/register",
    ]
    lib_paths = [
        f"-L{torch_dir}/lib",
        f"-L{cann_dir}/lib64",
    ]
    rpaths = [
        f"-Wl,-rpath,{torch_dir}/lib",
        f"-Wl,-rpath,{cann_dir}/lib64",
    ]
    libs = [
        "-Wl,--no-as-needed",
        "-lascendcl",
        "-lge_runner",
        "-lopp_registry",
        "-lopapi",
    ]

    # torch + torch_npu headers/libs only needed for Execute class (C++ path).
    # Pure REG_OP (Python path) only needs GE + CANN headers.
    if has_cpp_ops:
        libs.insert(0, "-ltorch")
        libs.insert(1, "-ltorch_cpu")
        libs.insert(2, "-lc10")
        if torch_npu_dir is not None:
            torch_npu_parent = os.path.dirname(torch_npu_dir)
            includes.extend(
                [
                    f"-I{torch_npu_dir}/include",
                    f"-I{torch_npu_parent}",
                ]
            )
            lib_paths.append(f"-L{torch_npu_dir}/lib")
            rpaths.append(f"-Wl,-rpath,{torch_npu_dir}/lib")
            libs.insert(libs.index("-lascendcl"), "-ltorch_npu")

    libs.append("-Wl,--as-needed")

    parts = [
        "g++",
        "-shared",
        "-fPIC",
        "-std=c++20",
        "-O2",
    ]
    parts.extend(includes)
    parts.extend(lib_paths)
    parts.extend(rpaths)
    parts.extend(libs)
    parts.extend(["-o", so_path, cpp_path])

    return parts


def compile_and_load(cpp_code: str, name: str, has_cpp_ops: bool = True) -> ctypes.CDLL:
    torch_dir = discover_torch_dir()
    torch_npu_dir = discover_torch_npu_dir() if has_cpp_ops else None
    cann_dir = discover_cann_dir()

    if not cann_dir:
        raise RuntimeError(
            "Environment variable 'ASCEND_HOME_PATH' is not set. "
            "Please source CANN environment script (e.g. setenv.bash) "
            "before compiling custom ops."
        )

    tmp_dir = _ensure_cpp_dir()
    cpp_path = os.path.join(tmp_dir, f"{name}.cpp")
    so_path = os.path.join(tmp_dir, f"{name}.so")

    Path(cpp_path).write_text(cpp_code, encoding="utf-8")

    cmd = build_gcc_command(torch_dir, torch_npu_dir, cann_dir, cpp_path, so_path, has_cpp_ops=has_cpp_ops)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120, check=False)

    if result.returncode != 0:
        detail = result.stderr or result.stdout
        raise RuntimeError(f"g++ compilation failed for '{name}':\n{detail}")

    lib = ctypes.CDLL(so_path, mode=os.RTLD_GLOBAL | os.RTLD_NOW)
    return lib
