from dataclasses import dataclass, field
from typing import FrozenSet, List, Optional
import logging
import torch
from torch._ops import OpOverload
from torch._C import DispatchKey

logger = logging.getLogger(__name__)


@dataclass
class SchemaArgInfo:
    name: str
    type_category: str          # "tensor", "tensor_list", "int", "float", "bool", "str", "Scalar", "int_list", "float_list", "bool_list", "scalar_list", "enum"
    has_default: bool = False
    is_optional: bool = False
    is_variadic: bool = False
    has_alias: bool = False
    is_alias_write: bool = False
    default_value: object = None
    is_out: bool = False
    is_kwarg_only: bool = False
    input_kind: int = 0         # aligned with delegate InputKind enum
    # --- per-return fields (set via alias group matching) ---
    alias_group: FrozenSet[str] = field(default_factory=frozenset)
    is_out_return: bool = False       # this return corresponds to an out arg
    is_inplace_return: bool = False   # this return corresponds to an inplace arg


@dataclass
class SchemaInfo:
    full_op_name: str
    namespace_name: str
    op_name: str
    overload: str = ""
    arguments: List[SchemaArgInfo] = field(default_factory=list)
    returns: List[SchemaArgInfo] = field(default_factory=list)
    is_inplace: bool = False
    is_out: bool = False
    has_variadic_input: bool = False
    out_return_indices: List[int] = field(default_factory=list)
    # arg index → return index, for out args matched via alias group
    out_arg_to_return: dict = field(default_factory=dict)


_BUILTIN_NAMESPACES = {"aten", "prim", "prims", "quantized", "_quantized"}

# InputKind enum values, aligned with torch-delegate fallback_codegen.h
_INPUT_KIND = {
    # (type_category, is_optional) -> InputKind value
    ("tensor", False): 0,       # TENSOR
    ("tensor", True): 1,        # OPTIONAL_TENSOR
    ("tensor_list", False): 2,  # TENSOR_LIST
    ("tensor_list", True): 2,   # TENSOR_LIST (no _OPT variant in delegate)
    ("int", False): 3,          # INT
    ("int", True): 4,           # INT_OPT
    ("float", False): 5,        # FLOAT
    ("float", True): 6,         # FLOAT_OPT
    ("bool", False): 7,         # BOOL
    ("bool", True): 8,          # BOOL_OPT
    ("str", False): 9,          # STRING
    ("str", True): 10,          # STRING_OPT
    ("int_list", False): 11,    # INT_LIST
    ("int_list", True): 12,     # INT_LIST_OPT
    ("float_list", False): 13,  # FLOAT_LIST
    ("float_list", True): 14,   # FLOAT_LIST_OPT
    ("bool_list", False): 15,   # BOOL_LIST
    ("bool_list", True): 16,    # BOOL_LIST_OPT
    ("Scalar", False): 17,      # SCALAR
    ("Scalar", True): 18,       # SCALAR_OPT
    ("scalar_list", False): 19, # SCALAR_LIST
    ("scalar_list", True): 19,  # SCALAR_LIST (no _OPT variant in delegate)
    ("enum", False): 20,        # SCALAR_TYPE
    ("enum", True): 21,         # SCALAR_TYPE_OPT
    ("str_list", False): 22,    # STRING_LIST (delegate has no STRING_LIST)
    ("str_list", True): 23,     # STRING_LIST_OPT (delegate has no STRING_LIST)
}


def _compute_input_kind(type_category: str, is_optional: bool) -> int:
    return _INPUT_KIND.get((type_category, is_optional), 0)


def is_custom_op(target) -> bool:
    if not isinstance(target, OpOverload):
        return False
    if not hasattr(target, '_schema'):
        return False
    namespace = target._schema.name.split("::", 1)[0]
    return namespace not in _BUILTIN_NAMESPACES


def determine_callback_path(target) -> Optional[str]:
    if not isinstance(target, OpOverload):
        raise RuntimeError(f"Target must be OpOverload, got {type(target)}")
    has_kernel = torch._C._dispatch_has_kernel_for_dispatch_key(
        target.name(), DispatchKey.PrivateUse1
    )

    if not has_kernel:
        logger.debug(
            "Op '%s' has no PrivateUse1 kernel, skipping auto-callback.",
            target.name(),
        )
        return None

    defined_in_python = getattr(target, "_defined_in_python", True)

    if not defined_in_python:
        logger.debug(
            "Op '%s' is C++-defined with a PrivateUse1 kernel, using cpp callback path.",
            target.name(),
        )
        return "cpp"

    # Python-defined op: use python callback path.
    # cpp path is more efficient but requires C++ compilation environment.
    # To use cpp path, define the op using TORCH_LIBRARY in C++ and set
    # _defined_in_python = False.
    logger.debug(
        "Op '%s' is Python-defined with a PrivateUse1 kernel, using python callback path.",
        target.name(),
    )

    return "python"


_SCALAR_GE_TENSOR_TYPE = {
    "int": "IntTensorType()",
    "float": "FloatTensorType()",
    "bool": "BoolTensorType()",
    "str": "StringTensorType()",
    "str_list": "StringTensorType()",
    "Scalar": "TensorType::ALL()",
    "int_list": "IntTensorType()",
    "float_list": "FloatTensorType()",
    "bool_list": "BoolTensorType()",
    "scalar_list": "TensorType::ALL()",
    "enum": "IntTensorType()",
}

# Derived from _SCALAR_GE_TENSOR_TYPE: all non-tensor, non-tensor_list categories
# are treated as scalar (value dependency) inputs. Kept as a separate variable for
# readability and O(1) membership test in _is_scalar_category.
_SCALAR_CATEGORIES = set(_SCALAR_GE_TENSOR_TYPE.keys())


def _is_scalar_category(type_category: str) -> bool:
    """All non-tensor, non-tensor_list categories are treated as scalar (value dependency) inputs."""
    return type_category in _SCALAR_CATEGORIES


def _classify_type(arg_type) -> str:
    type_str = str(arg_type)

    # Strip Optional[...] wrapper, aligned with delegate UnwrapOptional().
    # e.g. "Optional[int]" → "int", "Optional[Tensor]" → "Tensor"
    if type_str.startswith("Optional[") and type_str.endswith("]"):
        type_str = type_str[len("Optional["):-1]

    if type_str.startswith("Dict["):
        raise RuntimeError(f"Unsupported type: {type_str}")

    # Strip list wrapper: "Tensor[]" → "Tensor", "List[int]" → "int"
    inner = type_str
    is_list = False
    if type_str.endswith("[]") and len(type_str) > 2:
        inner = type_str[:-2]
        is_list = True
    elif type_str.startswith("List[") and type_str.endswith("]"):
        inner = type_str[len("List["):-1]
        is_list = True

    if is_list:
        if inner == "Tensor":
            return "tensor_list"
        if inner == "int":
            return "int_list"
        if inner == "float":
            return "float_list"
        if inner == "bool":
            return "bool_list"
        if inner == "str":
            return "str_list"
        if inner in ("Scalar", "number"):
            return "scalar_list"
        raise RuntimeError(f"Unsupported list type: {type_str}")

    if inner == "Tensor":
        return "tensor"

    if inner == "int":
        return "int"
    if inner == "float":
        return "float"
    if inner == "bool":
        return "bool"
    if inner == "str":
        return "str"
    if inner in ("Scalar", "Number", "number"):
        return "Scalar"
    if inner in ("ScalarType", "Layout", "Device", "MemoryFormat"):
        return "enum"

    raise RuntimeError(f"Unsupported type: {type_str}")


def _is_optional(arg_type) -> bool:
    return str(arg_type).startswith("Optional[")


def _is_tensor_list_type(arg_type) -> bool:
    type_str = str(arg_type)
    return "Tensor[]" in type_str or type_str == "List[Tensor]"


def _scalar_ge_tensor_type(type_category: str) -> str:
    return _SCALAR_GE_TENSOR_TYPE.get(type_category, "TensorType::ALL()")


def _extract_return_info(ret, index=0) -> SchemaArgInfo:
    name = ret.name if ret.name else (f"output_{index}")
    type_category = _classify_type(ret.type)
    is_optional = _is_optional(ret.type)
    is_variadic = _is_tensor_list_type(ret.type)
    has_alias = hasattr(ret, 'alias_info') and ret.alias_info is not None
    is_alias_write = has_alias and ret.alias_info.is_write
    alias_group = frozenset(ret.alias_info.before_set) if has_alias else frozenset()

    return SchemaArgInfo(
        name=name,
        type_category=type_category,
        is_optional=is_optional,
        is_variadic=is_variadic,
        has_alias=has_alias,
        is_alias_write=is_alias_write,
        alias_group=alias_group,
    )


def extract_schema_info(target: OpOverload) -> SchemaInfo:
    if not isinstance(target, OpOverload):
        raise RuntimeError(f"Target must be OpOverload, got {type(target)}")

    schema = target._schema
    full_op_name = schema.name
    namespace_name, op_name = schema.name.split("::", 1)
    overload = target._overloadname if target._overloadname != "default" else ""

    arguments = []
    has_variadic_input = False

    for arg in schema.arguments:
        type_category = _classify_type(arg.type)
        is_optional = _is_optional(arg.type)
        is_variadic = _is_tensor_list_type(arg.type)

        if is_variadic:
            has_variadic_input = True

        has_alias = hasattr(arg, 'alias_info') and arg.alias_info is not None
        is_alias_write = has_alias and arg.alias_info.is_write

        has_default = arg.has_default_value()
        default_value = arg.default_value if has_default else None

        # scalar_list does not support optional/default (torch schema limitation),
        # aligned with delegate which always uses SCALAR_LIST without _OPT variant
        if type_category == "scalar_list":
            is_optional = False
        else:
            # is_optional here serves GE OPTIONAL_INPUT semantics, not just
            # Optional[T] types: params with default values are also marked
            # optional so GE generates OPTIONAL_INPUT. The converter always
            # supplies a value (using default_value when missing), so GE
            # runtime never sees a missing input.
            is_optional = is_optional or has_default

        arg_info = SchemaArgInfo(
            name=arg.name,
            type_category=type_category,
            has_default=has_default,
            is_optional=is_optional,
            is_variadic=is_variadic,
            has_alias=has_alias,
            is_alias_write=is_alias_write,
            default_value=default_value,
            is_out=getattr(arg, 'is_out', False),
            is_kwarg_only=getattr(arg, 'kwarg_only', False),
            input_kind=_compute_input_kind(type_category, is_optional),
            alias_group=frozenset(arg.alias_info.before_set) if has_alias else frozenset(),
        )
        arguments.append(arg_info)

    returns = []

    for i, ret in enumerate(schema.returns):
        ret_info = _extract_return_info(ret, i)
        returns.append(ret_info)

    # --- Per-return alias group matching ---
    # Build alias group → (arg, arg_idx) mapping for non-empty groups.
    # Each non-variadic return with has_alias is matched to its corresponding
    # arg via the shared alias group (before_set). This determines whether the
    # return is an out-return (corresponds to an out arg) or an inplace-return
    # (corresponds to a mutated input arg).
    group_to_arg = {}
    for arg_idx, arg in enumerate(arguments):
        if arg.has_alias and arg.alias_group:
            for g in arg.alias_group:
                group_to_arg[g] = (arg, arg_idx)

    # arg index → return index, for out args matched via alias group
    out_arg_to_return = {}

    for i, ret in enumerate(returns):
        if ret.has_alias and ret.is_variadic:
            raise RuntimeError(
                f"Schema '{full_op_name}': return '{ret.name}' is both variadic (Tensor[]) "
                f"and has alias annotation. Variadic inplace return is not supported."
            )
        if not ret.has_alias or ret.is_variadic or not ret.alias_group:
            continue
        # Find the arg that shares an alias group with this return
        matched_arg = None
        matched_arg_idx = None
        for g in ret.alias_group:
            if g in group_to_arg:
                matched_arg, matched_arg_idx = group_to_arg[g]
                break
        if matched_arg is None:
            raise RuntimeError(
                f"Schema '{full_op_name}': return with alias group {ret.alias_group} "
                f"has no matching argument"
            )
        if matched_arg.is_out:
            ret.is_out_return = True
            if matched_arg_idx in out_arg_to_return:
                raise RuntimeError(
                    f"Schema '{full_op_name}': out arg '{matched_arg.name}' is matched by "
                    f"multiple returns (return {out_arg_to_return[matched_arg_idx]} and return {i}). "
                    f"One out arg mapping to multiple returns is not supported."
                )
            out_arg_to_return[matched_arg_idx] = i
        elif matched_arg.is_alias_write:
            ret.is_inplace_return = True
            # Use the arg name for REG_OP OUTPUT declaration (aligned with delegate)
            if matched_arg.name:
                ret.name = matched_arg.name
        else:
            # Read-only alias (e.g. view: Tensor(a) self -> Tensor(a))
            # Not supported — requires MakeOutputRefInput without write semantics
            raise RuntimeError(
                f"Schema '{full_op_name}': return has read-only alias "
                f"(group {ret.alias_group}, arg '{matched_arg.name}' is not out and not write). "
                f"Read-only alias returns (e.g. view ops) are not supported."
            )

    is_out = any(ret.is_out_return for ret in returns)
    is_inplace = any(ret.is_inplace_return for ret in returns)

    # Validate: every out arg must have a matching return via alias group
    for arg_idx, arg in enumerate(arguments):
        if arg.is_out and arg_idx not in out_arg_to_return:
            raise RuntimeError(
                f"Schema '{full_op_name}': out arg '{arg.name}' has no matching "
                f"return with the same alias group. Out args must have a corresponding "
                f"return with matching alias_info (e.g. Tensor(a!) out -> Tensor(a!))."
            )

    # out_return_indices: indices of returns that correspond to out args
    # (used for pre-allocation and out arg → return mapping)
    out_return_indices = [i for i, ret in enumerate(returns) if ret.is_out_return]

    return SchemaInfo(
        full_op_name=full_op_name,
        namespace_name=namespace_name,
        op_name=op_name,
        overload=overload,
        arguments=arguments,
        returns=returns,
        is_inplace=is_inplace,
        is_out=is_out,
        has_variadic_input=has_variadic_input,
        out_return_indices=out_return_indices,
        out_arg_to_return=out_arg_to_return,
    )


def find_inplace_arg_index(schema_info: SchemaInfo, ret: SchemaArgInfo) -> int:
    """Find the schema arg index that matches this inplace return via alias group."""
    for arg_idx, arg in enumerate(schema_info.arguments):
        if arg.is_alias_write and not arg.is_out and (arg.alias_group & ret.alias_group):
            return arg_idx
    raise RuntimeError(
        f"No matching inplace arg found for return with alias group {ret.alias_group}"
    )


def make_ge_op_name(schema_info: SchemaInfo) -> str:
    """Generate GE op identifier, aligned with torch-delegate GenerateGeOpIdentifier.

    Format: namespace__op_name[_overload] (e.g. "my_ops__my_op", "my_ops__my_op_Tensor")
    This avoids name collisions between different namespaces with same op names.
    """
    full_name = schema_info.full_op_name       # e.g. "my_ops::my_op"
    ge_name = full_name.replace("::", "__")    # e.g. "my_ops__my_op"
    if schema_info.overload:
        ge_name += "_" + schema_info.overload  # e.g. "my_ops__my_op_Tensor"
    return ge_name


def generate_reg_op(schema_info: SchemaInfo, ge_op_name: str) -> str:
    """Generate REG_OP + IMPL_OP with scalars as INPUT (value dependency), aligned with torch-delegate."""
    lines = [f"REG_OP({ge_op_name})"]

    for arg in schema_info.arguments:
        if arg.is_out:
            continue
        if arg.type_category == "tensor":
            if arg.is_optional:
                lines.append(f"  .OPTIONAL_INPUT({arg.name}, TensorType::ALL())")
            else:
                lines.append(f"  .INPUT({arg.name}, TensorType::ALL())")
        elif arg.type_category == "tensor_list":
            lines.append(f"  .DYNAMIC_INPUT({arg.name}, TensorType::ALL())")
        elif _is_scalar_category(arg.type_category):
            ge_type = _scalar_ge_tensor_type(arg.type_category)
            if arg.is_optional:
                lines.append(f"  .OPTIONAL_INPUT({arg.name}, {ge_type})")
            else:
                lines.append(f"  .INPUT({arg.name}, {ge_type})")

    if schema_info.has_variadic_input:
        lines.append("  .REQUIRED_ATTR(N, Int)")

    for i, ret in enumerate(schema_info.returns):
        name = ret.name if ret.name else ("y" if i == 0 else f"y{i}")
        if ret.type_category == "tensor_list":
            lines.append(f"  .DYNAMIC_OUTPUT({name}, TensorType::ALL())")
        else:
            lines.append(f"  .OUTPUT({name}, TensorType::ALL())")

    input_kinds = []
    for arg in schema_info.arguments:
        if arg.is_out:
            continue
        input_kinds.append(arg.input_kind)

    lines.append(f"  .ATTR(op_name, String, \"{schema_info.full_op_name}\")")
    lines.append(f"  .ATTR(overload, String, \"{schema_info.overload}\")")
    lines.append(f"  .ATTR(input_kinds, ListInt, {{{', '.join(str(k) for k in input_kinds)}}})")
    lines.append(f"  .ATTR(num_outputs, Int, {len(schema_info.returns)})")
    lines.append(f"  .ATTR(is_inplace, Bool, {'true' if schema_info.is_inplace else 'false'})")

    lines.append(f"  .OP_END_FACTORY_REG({ge_op_name})")

    reg_op_str = "\n".join(lines) + ";\n"

    # IMPL_OP with InputsDataDependency for scalar inputs
    dep_indices = []
    input_idx = 0
    for arg in schema_info.arguments:
        if arg.is_out:
            continue
        if _is_scalar_category(arg.type_category):
            dep_indices.append(input_idx)
        input_idx += 1

    impl_lines = [f"IMPL_OP({ge_op_name})"]
    if dep_indices:
        dep_str = ", ".join(str(i) for i in dep_indices)
        impl_lines.append(f"  .InputsDataDependency({{{dep_str}}});")
    else:
        impl_lines.append("  ;")

    return reg_op_str + "\n".join(impl_lines) + "\n"


def _scalar_to_ge_input(val, arg_info: SchemaArgInfo):
    """Convert a Python scalar to a GE Tensor for use as INPUT (not ATTR).

    Uses ge.Const() to create a proper Const node, aligned with how
    torchair's own converters create constant tensors."""
    from torchair.ge import Const, DataType
    import numpy as np

    if arg_info.type_category == "int":
        return Const(int(val), dtype=DataType.DT_INT64)
    elif arg_info.type_category == "float":
        return Const(float(val), dtype=DataType.DT_FLOAT)
    elif arg_info.type_category == "bool":
        return Const(bool(val), dtype=DataType.DT_BOOL)
    elif arg_info.type_category == "Scalar":
        if isinstance(val, int):
            return Const(int(val), dtype=DataType.DT_INT64)
        else:
            return Const(float(val), dtype=DataType.DT_FLOAT)
    elif arg_info.type_category == "str":
        from torchair.ge._ge_graph import get_default_ge_graph, next_unique_name, Tensor as GeTensor, compat_as_bytes
        graph = get_default_ge_graph()
        op = graph.op.add()
        op.type = "Const"
        op.name = next_unique_name(None, "Const")
        op.attr["dtype"].dt = DataType.DT_STRING
        tp = op.attr["value"].t
        tp.desc.dtype = DataType.DT_STRING
        tp.data = compat_as_bytes(str(val))
        op.output_desc.add().name = "y"
        op.output_desc[0].dtype = DataType.DT_STRING
        op.output_desc[0].shape.dim.extend([])
        return GeTensor(op, 0)
    elif arg_info.type_category == "str_list":
        from torchair.ge._ge_graph import get_default_ge_graph, next_unique_name, Tensor as GeTensor, compat_as_bytes
        graph = get_default_ge_graph()
        op = graph.op.add()
        op.type = "Const"
        op.name = next_unique_name(None, "Const")
        op.attr["dtype"].dt = DataType.DT_STRING
        tp = op.attr["value"].t
        tp.desc.dtype = DataType.DT_STRING
        joined = b'\0'.join(compat_as_bytes(str(v)) for v in val)
        tp.data = joined
        op.output_desc.add().name = "y"
        op.output_desc[0].dtype = DataType.DT_STRING
        op.output_desc[0].shape.dim.extend([len(val)])
        return GeTensor(op, 0)
    elif arg_info.type_category == "int_list":
        return Const(np.array([int(v) for v in val], dtype=np.int64), dtype=DataType.DT_INT64)
    elif arg_info.type_category == "float_list":
        return Const(np.array([float(v) for v in val], dtype=np.float32), dtype=DataType.DT_FLOAT)
    elif arg_info.type_category == "bool_list":
        return Const(np.array([bool(v) for v in val], dtype=np.bool_), dtype=DataType.DT_BOOL)
    elif arg_info.type_category == "scalar_list":
        if all(isinstance(v, int) for v in val):
            return Const(np.array([int(v) for v in val], dtype=np.int64), dtype=DataType.DT_INT64)
        else:
            return Const(np.array([float(v) for v in val], dtype=np.float32), dtype=DataType.DT_FLOAT)
    elif arg_info.type_category == "enum":
        return Const(int(val), dtype=DataType.DT_INT64)
    else:
        raise RuntimeError(f"Unsupported scalar type: {arg_info.type_category}")

def build_common_converter(schema_info: SchemaInfo, ge_op_name: str):
    """Build the common converter closure shared by both C++ and Python paths.

    The converter classifies arguments by type_category:
    - tensor → ge_inputs (directly passed as GE Tensor)
    - tensor_list → ge_inputs + ge_attrs["N"] (N is the count, still ATTR)
    - scalar types → ge_inputs (wrapped as Const node via _scalar_to_ge_input)

    Both C++ and Python paths use the same converter because REG_OP is identical
    (scalars as INPUT). The only difference is in Execute, not in converter.
    """
    _output_specs = []
    for i, ret in enumerate(schema_info.returns):
        name = ret.name if ret.name else ("y" if i == 0 else f"y{i}")
        _output_specs.append((name, ret.type_category == "tensor_list"))

    def converter(*args, meta_outputs=None, **kwargs):
        from torchair.ge.ge_custom import custom_op
        from torchair.ge import attr

        ge_inputs = {}
        ge_attrs = {}

        arg_idx = 0
        for schema_arg in schema_info.arguments:
            # Skip out args (e.g. 'out' in add.out).
            # out args are always kwarg_only (declared after '*' in schema),
            # so FX places them in kwargs, not in positional args.
            # Skipping them does not affect arg_idx (which counts positional args only).
            # Aligned with generate_reg_op which also skips is_out args for INPUT generation.
            if schema_arg.is_out:
                continue
            if schema_arg.type_category == "tensor":
                val = args[arg_idx] if arg_idx < len(args) else kwargs.get(schema_arg.name)
                ge_inputs[schema_arg.name] = val
                arg_idx += 1
            elif schema_arg.type_category == "tensor_list":
                val = args[arg_idx] if arg_idx < len(args) else kwargs.get(schema_arg.name)
                ge_inputs[schema_arg.name] = val
                ge_attrs["N"] = attr.Int(len(val))
                arg_idx += 1
            elif _is_scalar_category(schema_arg.type_category):
                val = args[arg_idx] if arg_idx < len(args) else kwargs.get(
                    schema_arg.name, schema_arg.default_value)
                ge_inputs[schema_arg.name] = _scalar_to_ge_input(val, schema_arg)
                arg_idx += 1
            else:
                logger.warning(
                    "Unsupported type_category '%s' for arg '%s' in op '%s', skipping.",
                    schema_arg.type_category, schema_arg.name, schema_info.full_op_name
                )
                arg_idx += 1

        ge_outputs = []
        for out_i, (name, is_dynamic) in enumerate(_output_specs):
            if is_dynamic:
                meta = meta_outputs
                if meta is not None:
                    if len(_output_specs) > 1 and isinstance(meta, (list, tuple)):
                        if out_i < len(meta):
                            meta = meta[out_i]
                        else:
                            raise RuntimeError(
                                f"meta_outputs has {len(meta)} elements but output {out_i} "
                                f"requires a dynamic output spec"
                            )
                if meta is not None and isinstance(meta, (list, tuple)):
                    ge_outputs.append((name, len(meta)))
                else:
                    ge_outputs.append((name, 1))
            else:
                ge_outputs.append(name)

        return custom_op(ge_op_name, inputs=ge_inputs, outputs=ge_outputs, attrs=ge_attrs)

    return converter


def register_callback_converter(target):
    """Register a callback converter for a custom op.

    Shared by both cpp and python paths — the converter only generates a
    custom_op node in the GE graph; the Execute implementation differs
    (cpp: .so, python: .py) but is handled at GE runtime, not in the converter.
    """
    schema_info = extract_schema_info(target)
    ge_op_name = make_ge_op_name(schema_info)

    converter = build_common_converter(schema_info, ge_op_name)

    from torchair._ge_concrete_graph.fx2ge_converter import register_fx_node_ge_converter
    register_fx_node_ge_converter(target)(converter)

    return converter
