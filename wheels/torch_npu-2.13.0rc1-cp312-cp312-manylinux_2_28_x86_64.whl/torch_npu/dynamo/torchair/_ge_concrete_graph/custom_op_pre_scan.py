import logging
import os

from torch._ops import OpOverload

logger = logging.getLogger(__name__)

_compiled_libs = []  # 持有 CDLL 引用，防止 GC 回收导致 dlclose

_python_path_deps_ok = None  # 缓存检测结果，避免重复 import


def _check_python_path_deps() -> bool:
    """检测 Python path 运行时依赖是否满足。

    依赖：
    - torch_npu.npu.streams.ExternalStream：stream 切换
    - ge.custom_op：EagerExecuteOp / register_op_impl 等执行框架
    """
    global _python_path_deps_ok
    if _python_path_deps_ok is not None:
        return _python_path_deps_ok
    missing = []
    try:
        # 仅验证模块可导入，不使用导入对象。noqa: F401 抑制"未使用导入"告警。
        from torch_npu.npu.streams import ExternalStream  # noqa: F401
    except ImportError:
        missing.append("torch_npu.npu.streams.ExternalStream")
    try:
        # 仅验证模块可导入，不使用导入对象。noqa: F401 抑制"未使用导入"告警。
        from ge.custom_op import EagerExecuteOp, register_op_impl  # noqa: F401
    except ImportError:
        missing.append("ge.custom_op")
    if missing:
        logger.warning(
            "Python path auto-callback dependencies missing: %s. "
            "Python path custom ops will be skipped. Please upgrade torch_npu / CANN.",
            ", ".join(missing),
        )
        _python_path_deps_ok = False
    else:
        _python_path_deps_ok = True
    return _python_path_deps_ok


def _is_ge_ir_registered(target):
    """Check if a custom op is already registered in GE IR.

    Returns:
        (True, None)     — GE IR found, original converter path can be used
        (False, None)    — GE IR not found, auto-callback should generate one
        (False, reason)  — query failed (API unavailable or exception),
                           auto-callback skipped to be safe
    """
    from torchair.core import _torchair  # pylint: disable=no-name-in-module

    try:
        target_name = str(target).split(".")[1]
        if target_name.split("_")[-1] == "functional":
            target_name = "_".join(target_name.split("_")[:-1])
        ge_name = "".join(word.capitalize() for word in target_name.split("_"))
        status, _, _, _ = _torchair.get_registered_ir_def(ge_name)
    except (RuntimeError, AttributeError, KeyError, IndexError) as e:
        return False, str(e)

    if status == "SUCCESS":
        return True, None
    if status == "ERROR":
        return False, None
    return False, "unsupported CANN version"


def prescan_and_compile_custom_ops(fx_graph, graph_id):
    from torchair._ge_concrete_graph.fx2ge_converter import _get_converter, _SPECIAL_TARGETS
    from torchair._ge_concrete_graph.custom_op_codegen_common import (
        is_custom_op,
        determine_callback_path,
        extract_schema_info,
        make_ge_op_name,
        register_callback_converter,
    )
    from torchair._ge_concrete_graph.custom_op_compiler import compile_and_load
    from torchair._ge_concrete_graph.custom_op_codegen_cpp import generate_cpp_source

    python_targets: set = set()
    cpp_targets: set = set()

    for node in fx_graph.nodes:
        if node.op != "call_function":
            continue

        target = node.target

        # Handle inplace ops wrapped in auto_functionalized_v2 HOP
        # The real OpOverload is in node.args[0]
        if str(target) == "auto_functionalized_v2":
            if node.args and isinstance(node.args[0], OpOverload):
                target = node.args[0]
            else:
                continue

        if not is_custom_op(target):
            continue

        # Skip ops with special handling in fx2ge_converter (e.g. air.scope_enter/exit)
        if str(target) in _SPECIAL_TARGETS:
            continue

        if target in python_targets or target in cpp_targets:
            continue

        if hasattr(target, "_ge_converter") and target._ge_converter is not None:
            continue

        try:
            converter = _get_converter(target)
            if converter is not None:
                continue
        except (KeyError, AttributeError):
            pass

        registered, reason = _is_ge_ir_registered(target)
        if registered:
            continue
        if reason is not None:
            logger.warning(f"Skip auto-callback for {target}: {reason}")
            continue

        callback_path = determine_callback_path(target)
        if callback_path is None:
            continue

        if callback_path == "python":
            if not _check_python_path_deps():
                continue
            python_targets.add(target)
        else:
            cpp_targets.add(target)

    if not python_targets and not cpp_targets:
        logger.debug("No custom ops requiring fallback compilation found")
        return

    all_targets = sorted(python_targets, key=lambda t: t.name()) + sorted(cpp_targets, key=lambda t: t.name())
    schemas = []
    ge_op_names = []
    cpp_op_indices = set()

    for i, target in enumerate(all_targets):
        schema_info = extract_schema_info(target)
        ge_op_name = make_ge_op_name(schema_info)
        schemas.append(schema_info)
        ge_op_names.append(ge_op_name)
        if target in cpp_targets:
            cpp_op_indices.add(i)

    # Build a unique name suffix: graph_id (process-unique, pid is in directory name).
    name_suffix = f"graph{graph_id}"

    # Step 1: g++ compile + dlopen (REG_OP registered to GE factory for all ops)
    cpp_code = generate_cpp_source(schemas, ge_op_names, cpp_op_indices)
    lib = compile_and_load(cpp_code, f"op_cpp_{name_suffix}", has_cpp_ops=bool(cpp_targets))
    _compiled_libs.append(lib)

    # Step 2: Python path — generate .py file with EagerExecuteOp subclasses.
    # _ensure_py_dir() (called inside) creates a process-level tmp directory on
    # first use and appends it to ASCEND_CUSTOM_OPP_PATH. GE's PreRun calls
    # LoadPythonCustomOpsIfNeeded each time, which scans the path and loads new
    # .py files (module_name includes abs(hash(file_path)) so no cache hit).
    if python_targets:
        from torchair._ge_concrete_graph.custom_op_codegen_python import generate_and_write_python_op_file

        python_schemas = [s for i, s in enumerate(schemas) if all_targets[i] in python_targets]
        python_target_list = [t for t in all_targets if t in python_targets]
        generate_and_write_python_op_file(python_schemas, python_target_list, name_suffix)

    # Step 3: register converters (so get_or_auto_gen_converter hits at step 1-2)
    for target in all_targets:
        register_callback_converter(target)

    logger.info(
        f"Batch compiled {len(all_targets)} custom ops (C++: {len(cpp_targets)}, Python: {len(python_targets)})"
    )
